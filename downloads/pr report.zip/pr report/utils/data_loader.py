import json

def load_data():
    with open("data/projects.json") as f:
        return json.load(f)["projects"]




import numpy as np

def calculate_phi(projects):
    if not projects:
        return 0
    return round(np.mean([p["phi"] for p in projects]), 2)

def gdp_impact(projects):
    if not projects:
        return 0
    return round(sum(p["gdpImpact"] for p in projects), 2)

def equity_score(projects):
    if not projects:
        return 0
    budgets = [p["budget"] for p in projects]
    if len(budgets) < 2:
        return 1
    return round(1 - np.std(budgets) / np.mean(budgets), 2)

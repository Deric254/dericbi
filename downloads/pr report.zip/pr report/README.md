# Presidential Report

A Dash-based dashboard for Kenya's development pulse.

## Local Development

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the app:
   ```bash
   python app.py
   ```

## Deployment on Render

This app is configured for easy deployment on Render:

1. Connect your GitHub repository to Render
2. Create a new Web Service
3. Select Python environment
4. Set the build command: `pip install -r requirements.txt`
5. Set the start command: `python app.py`
6. Deploy!

The app will automatically use the PORT environment variable set by Render.

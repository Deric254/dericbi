import dash
from dash import html, dcc, Input, Output
import dash_bootstrap_components as dbc
from utils.data_loader import load_data
from components.layout import build_layout, register_callbacks
import os

app = dash.Dash(__name__, external_stylesheets=[
    dbc.themes.BOOTSTRAP,
    "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
])
app.title = "Kenya at a Glance — Development Pulse"
server = app.server

data = load_data()
app.layout = build_layout(data)

# Register callbacks implemented in components/layout.py so KPIs and visuals
# are rendered and the filters update the dashboard.
register_callbacks(app, data)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8050))
    app.run(host='0.0.0.0', port=port, debug=False)

from dash import html, dcc
import dash_bootstrap_components as dbc
from datetime import datetime

def presidential_vision_section():
    # Key quotes
    quotes = [
        "“We must ensure that no region is left behind. Every Kenyan deserves a fair share of development.” — President William Ruto",
        "“The BETA programmes are about transforming lives — not just building infrastructure, but building hope.” — President William Ruto",
        "“Kenya’s future lies in the hands of our youth. We must empower them with tools, skills, and opportunity.” — President William Ruto",
        "“Every shilling must be accounted for. Development must be visible, measurable, and impactful.” — President William Ruto",
        "“CBC is not just a curriculum — it’s a commitment to future-proofing our children.” — President William Ruto",
        "“The Hustler Fund is about dignity, access, and economic justice for every Kenyan.” — President William Ruto"
    ]

    # Timeline of flagship achievements
    achievements = [
        {"year": 2023, "event": "Launch of Bottom-Up Economic Transformation Agenda (BETA)"},
        {"year": 2023, "event": "Hustler Fund disburses 1M loans in 6 months"},
        {"year": 2024, "event": "CBC curriculum rollout to all 47 counties"},
        {"year": 2024, "event": "NHIF reforms expand coverage to rural areas"},
        {"year": 2024, "event": "Digital economy initiatives create 100K+ jobs"}
    ]

    # National milestones for carousel
    milestones = [
        "1M Hustler Fund loans disbursed in 6 months",
        "CBC reaches 90,000 teachers nationwide",
        "NHIF covers dialysis in 47 counties",
        "BETA programs empower 500K youth",
        "Digital jobs created for 100,000 Kenyans"
    ]

    return html.Div([
        html.H3("🇰🇪 The President's Vision: A Kenya That Works for All", className="text-center mb-4"),

        # Quotes section
        dbc.Row([
            dbc.Col([
                html.H5("Key Presidential Quotes"),
                html.Div(id="quote-display", children=quotes[0], className="quote-box p-3"),
                dcc.Interval(id="quote-interval", interval=5000, n_intervals=0)
            ], width=6),

            dbc.Col([
                html.H5("Flagship Achievements Timeline"),
                html.Div([
                    html.Div([
                        html.Strong(f"{ach['year']}: "),
                        html.Span(ach['event'])
                    ], className="mb-2") for ach in achievements
                ])
            ], width=6)
        ], className="mb-4"),

        # Milestones carousel
        html.Div([
            html.H5("National Milestones"),
            html.Div(id="milestone-display", children=milestones[0], className="milestone-box p-3 text-center"),
            dcc.Interval(id="milestone-interval", interval=3000, n_intervals=0)
        ])
    ], className="presidential-vision-section")
from dash import html, dcc, Input, Output
import dash_bootstrap_components as dbc
import plotly.express as px
from components.kpis import render_kpis
from components.visuals import render_visuals
from components.story_layer import story_toggle
from components.presidential_vision import presidential_vision_section
from utils.calculations import calculate_phi, gdp_impact, equity_score
import pandas as pd

def build_layout(data):
    df = pd.DataFrame(data)
    regions = sorted(df["region"].unique())
    sectors = sorted(df["sector"].unique())
    years = sorted(df["year"].unique())
    programs = sorted(df["program"].unique())

    # Dynamically generate sector options
    sector_options = [{"label": "🌟 All Sectors", "value": "all"}]
    sector_options.extend([{"label": f"{'🏗️' if s == 'Infrastructure' else '📚' if s == 'Education' else '🏥' if s == 'Health' else '🌾' if s == 'Agriculture' else '💰' if s == 'Finance' else '👥' if s == 'Youth' else '💧' if s == 'Water' else '🚗' if s == 'Transport' else '🏖️' if s == 'Tourism' else '⚡' if s == 'Energy' else '🏭' if s == 'Manufacturing' else '🏠' if s == 'Housing' else '🛡️' if s == 'Security' else '🌱' if s == 'Environment' else '💻' if s == 'ICT' else '📊'} {s}", "value": s} for s in sectors])

    return dbc.Container([
        # Clean Patriotic Header
        dbc.Row([
            dbc.Col([
                html.Div([
                    html.Img(src="https://upload.wikimedia.org/wikipedia/commons/4/49/Flag_of_Kenya.svg",
                            style={"height": "35px", "marginRight": "10px"}, id="flag-img"),
                    dbc.Tooltip(
                        [
                            html.Div("DERIC MARANGU", style={"color": "#FFD700", "fontWeight": "bold"}),
                            html.Div("📊 Business/Data Analyst"),
                            html.Div("📧 dericmarangu@gmail.com"),
                            html.Div("📱 +254 791 360 805"),
                            html.Div("🌐 dericbi.netlify.app")
                        ],
                        target="flag-img",
                        placement="bottom"
                    ),
                    html.A([
                        html.Img(src="/assets/logo.png", style={"height": "35px", "width": "35px", "borderRadius": "50%", "border": "2px solid #FFD700", "marginRight": "10px", "transform": "rotate(-90deg)"}, id="logo-header-img")
                    ], href="https://dericbi.netlify.app", target="_blank", style={"textDecoration": "none"}),
                    dbc.Tooltip(
                        [
                            html.Div("DERIC MARANGU", style={"color": "#FFD700", "fontWeight": "bold"}),
                            html.Div("📊 Business/Data Analyst"),
                            html.Div("📧 dericmarangu@gmail.com"),
                            html.Div("📱 +254 791 360 805"),
                            html.Div("🌐 dericbi.netlify.app")
                        ],
                        target="logo-header-img",
                        placement="bottom"
                    ),
                    html.H2("🇰🇪 Kenya Development Pulse", className="mb-0 text-white fw-bold"),
                    html.Small(f"{min(years)}-{max(years)} • All Sectors", className="text-light d-block")
                ], className="d-flex align-items-center justify-content-center")
            ], width=12)
        ], className="py-3 mb-3", style={"background": "linear-gradient(90deg, #006600 0%, #000000 50%, #FF0000 100%)"}),

        # Main Content: Filters (Left) + Charts Grid (Right)
        dbc.Row([
            # Left Sidebar - Compact Filters
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🎛️ Filters", className="mb-0 text-center")),
                    dbc.CardBody([
                        html.Div([
                            html.Label("🎯 Sector:", className="form-label small fw-bold mb-1"),
                            dcc.Dropdown(
                                options=sector_options,
                                value="all",
                                id="sector-focus-filter",
                                className="mb-2",
                                style={"fontSize": "12px"}
                            ),

                            html.Label("📍 Region:", className="form-label small fw-bold mb-1"),
                            dcc.Dropdown(
                                options=[{"label": "🗺️ All Regions", "value": "all"}] + [{"label": r, "value": r} for r in regions],
                                value="all",
                                id="region-focus-filter",
                                className="mb-2",
                                style={"fontSize": "12px"}
                            ),

                            # Comprehensive Branding Section - Utilizing Full Sidebar Space
                            html.Div([
                                # Logo Section - Using Actual Logo
                                html.Div([
                                    html.A([
                                        html.Img(src="/assets/logo.png", style={"height": "60px", "width": "60px", "borderRadius": "50%", "border": "3px solid #FFD700", "marginBottom": "10px", "transform": "rotate(-90deg)"}, id="logo-sidebar-img")
                                    ], href="https://dericbi.netlify.app", target="_blank", className="d-block"),
                                    dbc.Tooltip(
                                        [
                                            html.Div("DERIC MARANGU", style={"color": "#FFD700", "fontWeight": "bold"}),
                                            html.Div("📊 Business/Data Analyst"),
                                            html.Div("📧 dericmarangu@gmail.com"),
                                            html.Div("📱 +254 791 360 805"),
                                            html.Div("🌐 dericbi.netlify.app")
                                        ],
                                        target="logo-sidebar-img",
                                        placement="right"
                                    ),
                                    html.Div([
                                        html.Span("🇰🇪", style={"fontSize": "32px", "marginRight": "10px"}),
                                        html.Span("DERIC MARANGU", style={"fontSize": "16px", "fontWeight": "bold", "color": "#FFD700"})
                                    ], className="d-flex align-items-center justify-content-center")
                                ], className="text-center mb-4"),

                                # Main Branding Title
                                html.H4("🇰🇪 Kenya Development", className="text-center mb-3", style={"fontSize": "18px", "color": "#FFD700", "fontWeight": "bold"}),
                                html.P(f"{min(years)}-{max(years)} • Deriving Extreme Clarity", className="text-center mb-4", style={"fontSize": "14px", "color": "#FFFFFF", "fontWeight": "bold"}),

                                # 7 Sound Bites - Much Larger & More Legible
                                html.Div([
                                    html.Div("🎯 Vision → Results", className="text-center fw-bold mb-3", style={"fontSize": "14px", "color": "#FFD700", "fontWeight": "bold"}),
                                    html.Div("📊 Data-Driven Impact", className="text-center mb-3", style={"fontSize": "13px", "color": "#00D4AA", "fontWeight": "bold"}),
                                    html.Div("🚀 Deriving Extreme Clarity", className="text-center mb-3", style={"fontSize": "13px", "color": "#FFFFFF", "fontWeight": "bold"}),
                                    html.Div("💡 Innovation & Excellence", className="text-center mb-3", style={"fontSize": "13px", "color": "#28A745", "fontWeight": "bold"}),
                                    html.Div("🌟 Transforming Kenya", className="text-center mb-3", style={"fontSize": "13px", "color": "#007BFF", "fontWeight": "bold"}),
                                    html.Div("⚡ Precision Analytics", className="text-center mb-3", style={"fontSize": "13px", "color": "#DC3545", "fontWeight": "bold"}),
                                    html.Div("🎪 Creative Solutions", className="text-center mb-3", style={"fontSize": "13px", "color": "#FFC107", "fontWeight": "bold"}),
                                ], className="mb-4"),

                                # Contact Information Section
                                html.Div([
                                    html.H6("📞 CONTACT ME", className="text-center mb-3", style={"fontSize": "14px", "color": "#FFD700", "fontWeight": "bold"}),
                                    html.Div([
                                        html.I(className="fab fa-whatsapp me-2", style={"color": "#25D366"}),
                                        html.A("+254 791 360 805", href="https://wa.me/254791360805", target="_blank",
                                              style={"color": "#25D366", "textDecoration": "none", "fontSize": "13px", "fontWeight": "bold"})
                                    ], className="text-center mb-2"),
                                    html.Div([
                                        html.I(className="fas fa-envelope me-2", style={"color": "#DC3545"}),
                                        html.A("dericmarangu@gmail.com", href="mailto:dericmarangu@gmail.com",
                                              style={"color": "#DC3545", "textDecoration": "none", "fontSize": "13px", "fontWeight": "bold"})
                                    ], className="text-center mb-3")
                                ], className="mb-4"),

                                # Website Link
                                html.Div([
                                    html.H6("🌐 VISIT MY WEBSITE", className="text-center mb-2", style={"fontSize": "14px", "color": "#FFD700", "fontWeight": "bold"}),
                                    html.A([
                                        html.I(className="fas fa-globe me-2"),
                                        "dericbi.netlify.app"
                                    ], href="https://dericbi.netlify.app", target="_blank",
                                         className="btn btn-outline-warning btn-sm d-block mx-auto",
                                         style={"fontSize": "12px", "fontWeight": "bold", "borderColor": "#FFD700", "color": "#FFD700"})
                                ], className="mb-4"),

                                # Professional Signature
                                html.Div([
                                    html.Hr(style={"borderColor": "#FFD700", "borderWidth": "3px", "margin": "20px 0"}),
                                    html.P("🇰🇪 Kenyan Data Expert & Developer", className="text-center mb-1", style={"fontSize": "14px", "color": "#FFD700", "fontWeight": "bold"}),
                                    html.P("*Transforming Data into Impact*", className="text-center", style={"fontSize": "12px", "color": "#FFFFFF", "fontStyle": "italic"})
                                ])
                            ], className="mt-4 p-4", style={"background": "linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 50%, #2d2d2d 100%)", "borderRadius": "15px", "border": "4px solid #FFD700", "boxShadow": "0 8px 16px rgba(255,215,0,0.5)", "minHeight": "600px"})
                        ], style={"padding": "10px", "height": "800px", "overflowY": "auto"})
                    ], style={"padding": "10px"})
                ], className="shadow-sm", style={"height": "862px"})
            ], width=2),

            # Right Charts Grid - 4 Charts
            dbc.Col([
                dbc.Row([
                    # Chart 1: GDP Growth Over Time with 2 KPIs above
                    dbc.Col([
                        # KPIs above chart
                        dbc.Row([
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.Div(id="kpi-total-budget")
                                    ], style={"padding": "4px"})
                                ], className="text-center mb-1", style={"minHeight": "45px"})
                            ], width=6),
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.Div(id="kpi-completed-projects")
                                    ], style={"padding": "4px"})
                                ], className="text-center mb-1", style={"minHeight": "45px"})
                            ], width=6)
                        ], className="mb-1"),
                        # Chart below KPIs
                        dbc.Card([
                            dbc.CardBody([
                                html.H6("📈 GDP Growth Trend", className="text-center mb-2", style={"fontSize": "14px"}),
                                html.Div(id="gdp-growth-chart", style={"height": "350px"})
                            ], style={"padding": "8px"})
                        ], className="shadow-sm")
                    ], width=6),

                    # Chart 2: Sector Pareto Chart with 2 KPIs above
                    dbc.Col([
                        # KPIs above chart
                        dbc.Row([
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.Div(id="kpi-avg-phi")
                                    ], style={"padding": "4px"})
                                ], className="text-center mb-1", style={"minHeight": "45px"})
                            ], width=6),
                            dbc.Col([
                                dbc.Card([
                                    dbc.CardBody([
                                        html.Div(id="kpi-total-gdp")
                                    ], style={"padding": "4px"})
                                ], className="text-center mb-1", style={"minHeight": "45px"})
                            ], width=6)
                        ], className="mb-1"),
                        # Chart below KPIs
                        dbc.Card([
                            dbc.CardBody([
                                html.H6("📊 Sector GDP Contribution", className="text-center mb-2", style={"fontSize": "14px"}),
                                html.Div(id="sector-pareto-chart", style={"height": "350px"})
                            ], style={"padding": "8px"})
                        ], className="shadow-sm")
                    ], width=6)
                ], className="mb-2"),

                dbc.Row([
                    # Chart 3: Regional GDP Contribution
                    dbc.Col([
                        dbc.Card([
                            dbc.CardBody([
                                html.H6("🗺️ Regional GDP Impact", className="text-center mb-2", style={"fontSize": "14px"}),
                                html.Div(id="regional-gdp-chart", style={"height": "350px"})
                            ], style={"padding": "8px"})
                        ], className="shadow-sm mb-2")
                    ], width=6),

                    # Chart 4: Budget vs GDP Impact
                    dbc.Col([
                        dbc.Card([
                            dbc.CardBody([
                                html.H6("💰 Budget Efficiency", className="text-center mb-2", style={"fontSize": "14px"}),
                                html.Div(id="budget-efficiency-chart", style={"height": "350px"})
                            ], style={"padding": "8px"})
                        ], className="shadow-sm mb-2")
                    ], width=6)
                ])
            ], width=10)
        ], className="mb-3")

    ], fluid=True)

# Callback wiring
def format_number(num):
    """Format number with appropriate suffix (k, M, B, T)"""
    if num >= 1e12:
        return f"{num/1e12:.2f}T"
    elif num >= 1e9:
        return f"{num/1e9:.2f}B"
    elif num >= 1e6:
        return f"{num/1e6:.2f}M"
    elif num >= 1e3:
        return f"{num/1e3:.2f}k"
    else:
        return f"{num:.2f}"

def register_callbacks(app, data):
    @app.callback(
        Output("gdp-growth-chart", "children"),
        Output("sector-pareto-chart", "children"),
        Output("regional-gdp-chart", "children"),
        Output("budget-efficiency-chart", "children"),
        Output("kpi-total-budget", "children"),
        Output("kpi-completed-projects", "children"),
        Output("kpi-avg-phi", "children"),
        Output("kpi-total-gdp", "children"),
        Input("sector-focus-filter", "value"),
        Input("region-focus-filter", "value")
    )
    def update_main_view(sector_focus, region_focus):
        df = pd.DataFrame(data)

        # Apply filters
        if sector_focus != "all":
            df = df[df["sector"] == sector_focus]
        if region_focus != "all":
            df = df[df["region"] == region_focus]

        # Handle empty DataFrame after filtering
        if df.empty:
            # Create empty state KPIs
            kpi_total_budget = [
                html.H6("💰 Total", className="card-title text-success mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
                html.H6("KSh 0.00", className="text-success fw-bold mb-0", style={"fontSize": "18px", "lineHeight": "1.2"}),
                html.Small("No data", className="text-muted", style={"fontSize": "10px"})
            ]

            kpi_completed_projects = [
                html.H6("✅ Done", className="card-title text-primary mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
                html.H6("0", className="text-primary fw-bold mb-0", style={"fontSize": "18px", "lineHeight": "1.2"}),
                html.Small("of 0", className="text-muted", style={"fontSize": "10px"})
            ]

            kpi_avg_phi = [
                html.H6("🎯 Score", className="card-title text-warning mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
                html.H6("0.00/100", className="text-warning fw-bold mb-0", style={"fontSize": "18px", "lineHeight": "1.2"}),
                html.Small("PHI Avg", className="text-muted", style={"fontSize": "10px"})
            ]

            kpi_total_gdp = [
                html.H6("📈 GDP", className="card-title text-info mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
                html.H6("0.0%", className="text-info fw-bold mb-0", style={"fontSize": "18px", "lineHeight": "1.2"}),
                html.Small("Growth", className="text-muted", style={"fontSize": "10px"})
            ]

            # Create empty state charts
            gdp_growth_chart = create_gdp_growth_chart(df)
            sector_pareto_chart = create_sector_pareto_chart(df)
            regional_gdp_chart = create_regional_gdp_chart(df)
            budget_efficiency_chart = create_budget_efficiency_chart(df)

            return gdp_growth_chart, sector_pareto_chart, regional_gdp_chart, budget_efficiency_chart, kpi_total_budget, kpi_completed_projects, kpi_avg_phi, kpi_total_gdp

        # Calculate KPI values
        total_budget = df["budget"].sum()
        completed_projects = len(df[df["status"] == "Completed"])
        avg_phi = df["phi"].mean()
        if pd.isna(avg_phi):
            avg_phi = 0.0
        total_gdp = df["gdpImpact"].sum()

        # Create KPI content
        kpi_total_budget = [
            html.H6("💰 Total", className="card-title text-success mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
            html.H6(f"KSh {format_number(total_budget)}", className="text-success fw-bold mb-0", style={"fontSize": "18px", "lineHeight": "1.2"}),
            html.Small(f"{min(df['year'])}-{max(df['year'])}", className="text-muted", style={"fontSize": "10px"})
        ]

        kpi_completed_projects = [
            html.H6("✅ Done", className="card-title text-primary mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
            html.H6(f"{completed_projects}", className="text-primary fw-bold mb-0", style={"fontSize": "18px", "lineHeight": "1.2"}),
            html.Small(f"of {len(df)}", className="text-muted", style={"fontSize": "10px"})
        ]

        kpi_avg_phi = [
            html.H6("🎯 Score", className="card-title text-warning mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
            html.H6(f"{avg_phi:.2f}/100", className="text-warning fw-bold mb-0", style={"fontSize": "18px", "lineHeight": "1.2"}),
            html.Small("PHI Avg", className="text-muted", style={"fontSize": "10px"})
        ]

        kpi_total_gdp = [
            html.H6("📈 GDP", className="card-title text-info mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
            html.H6(f"{total_gdp:.1f}%", className="text-info fw-bold mb-0", style={"fontSize": "18px", "lineHeight": "1.2"}),
            html.Small("Growth", className="text-muted", style={"fontSize": "10px"})
        ]

        # Create all charts
        gdp_growth_chart = create_gdp_growth_chart(df)
        sector_pareto_chart = create_sector_pareto_chart(df)
        regional_gdp_chart = create_regional_gdp_chart(df)
        budget_efficiency_chart = create_budget_efficiency_chart(df)

        return gdp_growth_chart, sector_pareto_chart, regional_gdp_chart, budget_efficiency_chart, kpi_total_budget, kpi_completed_projects, kpi_avg_phi, kpi_total_gdp

def create_timeline_chart(df):
    """Create the main development timeline chart"""
    if df.empty:
        return html.Div("No data available for selected filters", className="text-center text-muted py-4")

    # Aggregate data by year and sector
    yearly_data = df.groupby(["year", "sector"]).agg({
        "budget": "sum",
        "phi": "mean",
        "gdpImpact": "sum"
    }).reset_index()

    # Create timeline chart
    fig = px.bar(
        yearly_data,
        x="year",
        y="budget",
        color="sector",
        title="Annual Development Investment by Sector",
        labels={"budget": "Budget (KSh)", "year": "Year", "sector": "Sector"},
        barmode="stack"
    )

    fig.update_layout(
        height=400,
        showlegend=True,
        legend_title="Sectors",
        xaxis_title="Year",
        yaxis_title="Budget (KSh)"
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False})

def create_sector_highlights(df):
    """Create ultra-compact sector highlight cards"""
    if df.empty:
        return dbc.Row([])

    highlights = []

    # Total investment - Ultra Compact
    total_budget = df["budget"].sum()
    highlights.append(
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H6("💰 Total", className="card-title text-success mb-0", style={"fontSize": "10px", "lineHeight": "1.2"}),
                    html.H6(f"KSh {total_budget/1000000:.0f}M", className="text-success fw-bold mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
                    html.Small("2022-25", className="text-muted", style={"fontSize": "8px"})
                ], style={"padding": "4px"})
            ], className="text-center", style={"minHeight": "50px"})
        ], width=2)
    )

    # Projects completed - Ultra Compact
    completed_projects = len(df[df["status"] == "Completed"])
    highlights.append(
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H6("✅ Done", className="card-title text-primary mb-0", style={"fontSize": "10px", "lineHeight": "1.2"}),
                    html.H6(f"{completed_projects}", className="text-primary fw-bold mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
                    html.Small(f"of {len(df)}", className="text-muted", style={"fontSize": "8px"})
                ], style={"padding": "4px"})
            ], className="text-center", style={"minHeight": "50px"})
        ], width=2)
    )

    # Average PHI score - Ultra Compact
    avg_phi = df["phi"].mean()
    highlights.append(
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H6("🎯 Score", className="card-title text-warning mb-0", style={"fontSize": "10px", "lineHeight": "1.2"}),
                    html.H6(f"{avg_phi:.0f}/100", className="text-warning fw-bold mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
                    html.Small("PHI Avg", className="text-muted", style={"fontSize": "8px"})
                ], style={"padding": "4px"})
            ], className="text-center", style={"minHeight": "50px"})
        ], width=2)
    )

    # GDP Impact - Ultra Compact
    total_gdp = df["gdpImpact"].sum()
    highlights.append(
        dbc.Col([
            dbc.Card([
                dbc.CardBody([
                    html.H6("📈 GDP", className="card-title text-info mb-0", style={"fontSize": "10px", "lineHeight": "1.2"}),
                    html.H6(f"{total_gdp:.1f}%", className="text-info fw-bold mb-0", style={"fontSize": "12px", "lineHeight": "1.2"}),
                    html.Small("Growth", className="text-muted", style={"fontSize": "8px"})
                ], style={"padding": "4px"})
            ], className="text-center", style={"minHeight": "50px"})
        ], width=2)
    )

    # Add empty columns to center the 4 KPIs
    highlights.insert(0, dbc.Col([], width=1))  # Left spacer
    highlights.append(dbc.Col([], width=1))     # Right spacer

    return dbc.Row(highlights, className="mb-2", style={"maxHeight": "60px"})

def create_gdp_growth_chart(df):
    """Create GDP growth over time line chart"""
    if df.empty:
        return html.Div("No data available", className="text-center text-muted py-3", style={"fontSize": "12px"})

    # Aggregate GDP impact by year
    yearly_gdp = df.groupby("year")["gdpImpact"].sum().reset_index()

    fig = px.line(
        yearly_gdp,
        x="year",
        y="gdpImpact",
        title="GDP Growth Trend",
        labels={"gdpImpact": "GDP Impact (%)", "year": "Year"},
        markers=True,
        text=yearly_gdp["gdpImpact"].round(1).astype(str) + "%"
    )

    fig.update_layout(
        height=350,
        margin=dict(l=20, r=20, t=30, b=20),
        font=dict(size=10),
        showlegend=False
    )

    fig.update_traces(
        line=dict(color="#006600", width=3), 
        marker=dict(size=6, color="#FF0000"),
        mode="lines+markers+text",
        textposition="top center",
        textfont=dict(size=12, color="black")
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False}, style={"height": "100%", "width": "100%"})

def create_sector_pareto_chart(df):
    """Create sector contribution Pareto chart"""
    if df.empty:
        return html.Div("No data available", className="text-center text-muted py-3", style={"fontSize": "12px"})

    # Aggregate by sector
    sector_gdp = df.groupby("sector")["gdpImpact"].sum().reset_index()
    sector_gdp = sector_gdp.sort_values("gdpImpact", ascending=False)

    # Calculate cumulative percentage
    sector_gdp["cumulative"] = sector_gdp["gdpImpact"].cumsum()
    sector_gdp["cumulative_pct"] = (sector_gdp["cumulative"] / sector_gdp["gdpImpact"].sum()) * 100

    fig = px.bar(
        sector_gdp,
        x="sector",
        y="gdpImpact",
        title="Sector GDP Contribution",
        labels={"gdpImpact": "GDP Impact (%)", "sector": "Sector"},
        color="gdpImpact",
        color_continuous_scale=["#006600", "#FF0000"]
    )

    # Add cumulative line
    fig.add_scatter(
        x=sector_gdp["sector"],
        y=sector_gdp["cumulative_pct"],
        mode="lines+markers",
        name="Cumulative %",
        yaxis="y2",
        line=dict(color="#FFD700", width=2),
        marker=dict(size=4)
    )

    fig.update_layout(
        height=350,
        margin=dict(l=20, r=20, t=30, b=20),
        font=dict(size=10),
        showlegend=False,
        yaxis2=dict(
            title="Cumulative %",
            overlaying="y",
            side="right",
            range=[0, 100]
        )
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False}, style={"height": "100%", "width": "100%"})

def create_regional_gdp_chart(df):
    """Create regional GDP contribution pie chart"""
    if df.empty:
        return html.Div("No data available", className="text-center text-muted py-3", style={"fontSize": "12px"})

    # Aggregate by region
    regional_gdp = df.groupby("region")["gdpImpact"].sum().reset_index()
    regional_gdp = regional_gdp[regional_gdp["gdpImpact"] > 0]  # Filter out zero values

    fig = px.pie(
        regional_gdp,
        values="gdpImpact",
        names="region",
        title="Regional GDP Impact",
        color_discrete_sequence=["#006600", "#FF0000", "#000000", "#FFD700", "#0080FF", "#800080", "#FFA500", "#00FF00"]
    )

    fig.update_layout(
        height=350,
        margin=dict(l=20, r=20, t=30, b=20),
        font=dict(size=10),
        showlegend=True,
        legend=dict(font=dict(size=8))
    )

    fig.update_traces(textposition="inside", textinfo="percent+label", textfont_size=8)

    return dcc.Graph(figure=fig, config={"displayModeBar": False}, style={"height": "100%", "width": "100%"})

def create_budget_efficiency_chart(df):
    """Create budget vs GDP impact scatter plot"""
    if df.empty:
        return html.Div("No data available", className="text-center text-muted py-3", style={"fontSize": "12px"})

    # Aggregate by sector for efficiency analysis
    sector_data = df.groupby("sector").agg({
        "budget": "sum",
        "gdpImpact": "sum"
    }).reset_index()

    # Calculate efficiency ratio
    sector_data["efficiency"] = sector_data["gdpImpact"] / (sector_data["budget"] / 1000000000)  # GDP per billion KSh

    fig = px.scatter(
        sector_data,
        x="budget",
        y="gdpImpact",
        size="efficiency",
        color="sector",
        title="Budget vs GDP Impact",
        labels={"budget": "Budget (KSh)", "gdpImpact": "GDP Impact (%)", "sector": "Sector"},
        color_discrete_sequence=["#006600", "#FF0000", "#000000", "#FFD700"]
    )

    fig.update_layout(
        height=350,
        margin=dict(l=20, r=20, t=30, b=20),
        font=dict(size=10),
        showlegend=False
    )

    return dcc.Graph(figure=fig, config={"displayModeBar": False}, style={"height": "100%", "width": "100%"})
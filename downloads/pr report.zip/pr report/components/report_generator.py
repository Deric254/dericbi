import pandas as pd
from datetime import datetime

def generate_html_report(filtered_data):
    df = pd.DataFrame(filtered_data)
    total_budget = df["budget"].sum()
    avg_phi = round(df["phi"].mean(), 2)
    gdp_impact = round(df["gdpImpact"].sum(), 2)

    html = f"""
    <html>
    <head>
        <title>Kenya Development Pulse — Executive Report</title>
        <style>
            body {{ font-family: Arial; padding: 20px; background-color: #f4f4f4; }}
            h1 {{ color: #006400; }}
            .section {{ margin-bottom: 30px; }}
            .quote {{ font-style: italic; color: #555; }}
        </style>
    </head>
    <body>
        <h1>🇰🇪 Kenya Development Pulse — Executive Report</h1>
        <p><strong>Date:</strong> {datetime.now().strftime('%A, %d %B %Y — %I:%M %p')}</p>

        <div class="section">
            <h2>Key Metrics</h2>
            <ul>
                <li><strong>Total Budget:</strong> KSh {total_budget:,.0f}</li>
                <li><strongAverage PHI:</strong> {avg_phi}</li>
                <li><strong>GDP Impact:</strong> {gdp_impact}%</li>
            </ul>
        </div>

        <div class="section">
            <h2>Projects Overview</h2>
            <table border="1" cellpadding="5" cellspacing="0">
                <tr>
                    <th>Region</th><th>County</th><th>Sector</th><th>Project</th><th>Budget</th><th>PHI</th><th>Status</th>
                </tr>
                {''.join([
                    f"<tr><td>{p['region']}</td><td>{p['county']}</td><td>{p['sector']}</td><td>{p['project']}</td><td>KSh {p['budget']:,.0f}</td><td>{p['phi']}</td><td>{p['status']}</td></tr>"
                    for p in filtered_data
                ])}
            </table>
        </div>

        <div class="section">
            <h2>Presidential Quote</h2>
            <p class="quote">“Every shilling must be accounted for. Development must be visible, measurable, and impactful.” — President Ruto</p>
        </div>

        <footer>
            <p>Prepared by Deric Marangu — Deriving Extreme Clarity for Stakeholders</p>
        </footer>
    </body>
    </html>
    """
    return html

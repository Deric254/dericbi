from dash import html
import dash_bootstrap_components as dbc
from utils.calculations import calculate_phi, gdp_impact, equity_score

def render_kpis(data):
    total_budget = sum(p["budget"] for p in data) if data else 0
    phi = calculate_phi(data) if data else 0
    gdp = gdp_impact(data) if data else 0
    equity = equity_score(data) if data else 0
    project_count = len(data) if data else 0

    # Dynamic budget formatting
    def format_budget(budget):
        if budget >= 1e12:
            return f"KSh {budget/1e12:.2f}T"
        elif budget >= 1e9:
            return f"KSh {budget/1e9:.2f}B"
        elif budget >= 1e6:
            return f"KSh {budget/1e6:.2f}M"
        elif budget >= 1e3:
            return f"KSh {budget/1e3:.2f}k"
        else:
            return f"KSh {budget:.2f}"

    return dbc.Container([
        html.H5("📈 Key Performance Indicators", className="text-center mb-3 text-white"),

        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.Div("💰", className="text-center display-4"),
                        html.H3(format_budget(total_budget), className="text-center text-success fw-bold"),
                        html.P("Total Budget Allocated", className="text-center text-muted small mb-0")
                    ])
                ], className="text-center shadow-sm border-0 bg-light")
            ], width=3),

            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.Div("📊", className="text-center display-4"),
                        html.H3(f"{gdp}%", className="text-center text-info fw-bold"),
                        html.P("GDP Impact Score", className="text-center text-muted small mb-0")
                    ])
                ], className="text-center shadow-sm border-0 bg-light")
            ], width=3),

            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.Div("🎯", className="text-center display-4"),
                        html.H3(f"{phi}/100", className="text-center text-warning fw-bold"),
                        html.P("Performance Health Index", className="text-center text-muted small mb-0")
                    ])
                ], className="text-center shadow-sm border-0 bg-light")
            ], width=3),

            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.Div("⚖️", className="text-center display-4"),
                        html.H3(f"{equity:.2f}", className="text-center text-danger fw-bold"),
                        html.P("Regional Equity Score", className="text-center text-muted small mb-0")
                    ])
                ], className="text-center shadow-sm border-0 bg-light")
            ], width=3)
        ]),

        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.Div("🏗️", className="text-center display-4"),
                        html.H3(f"{project_count}", className="text-center text-primary fw-bold"),
                        html.P("Active Projects", className="text-center text-muted small mb-0")
                    ])
                ], className="text-center shadow-sm border-0 bg-light")
            ], width=12, className="mt-2")
        ])
    ], fluid=True)

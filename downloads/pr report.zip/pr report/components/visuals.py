from dash import dcc, html
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

def render_visuals(data):
    df = pd.DataFrame(data)

    if df.empty:
        return html.Div("No data available for selected filters", className="text-center text-muted py-5")

    # Dynamic county coordinates mapping
    county_coords = {
        "Nyeri": (-0.4278, 36.9476), "Kitui": (-1.3667, 38.0106), "Mombasa": (-4.0435, 39.6682),
        "Nakuru": (-0.3031, 36.0800), "Kakamega": (0.2827, 34.7519), "Kisumu": (-0.0917, 34.7680),
        "Garissa": (-0.4532, 39.6589), "Nairobi": (-1.2921, 36.8219), "Kiambu": (-1.1714, 36.8356),
        "Kwale": (-4.1737, 39.4583), "Murang'a": (-0.7833, 37.0333), "Uasin Gishu": (0.5167, 35.2833),
        "Bungoma": (0.5667, 34.5667), "Kisii": (-0.6833, 34.7667), "Meru": (0.0500, 37.6500),
        "Machakos": (-1.5167, 37.2667), "Wajir": (1.7500, 40.0667), "Kilifi": (-3.6333, 39.8667),
        "All": (0.0236, 37.9062)
    }

    # Add coordinates to dataframe dynamically
    df["lat"] = df["county"].map({county: coords[0] for county, coords in county_coords.items()})
    df["lon"] = df["county"].map({county: coords[1] for county, coords in county_coords.items()})

    map_fig = px.scatter_mapbox(
        df,
        lat="lat", lon="lon",
        hover_name="project",
        hover_data=["sector", "budget", "phi", "region"],
        color="region",
        size="budget",
        zoom=5.5,
        height=350
    )
    map_fig.update_layout(
        mapbox_style="open-street-map",
        title="🏗️ Project Distribution Across Kenya",
        title_font_size=16,
        margin=dict(l=0, r=0, t=40, b=0)
    )
    map_fig.update_traces(marker=dict(sizemin=5))

    # Enhanced Budget by Region - Horizontal Bar Chart
    region_budget = df.groupby("region")["budget"].sum().reset_index()
    region_budget = region_budget.sort_values("budget", ascending=True)

    bar_fig = px.bar(
        region_budget,
        y="region",
        x="budget",
        orientation='h',
        title="💰 Budget Allocation by Region (KSh)",
        labels={"budget": "Budget (KSh)", "region": "Region"},
        height=350
    )
    bar_fig.update_layout(
        title_font_size=16,
        margin=dict(l=0, r=0, t=40, b=0),
        yaxis_title="",
        xaxis_title=""
    )
    bar_fig.update_traces(texttemplate='%{x:,.2f}', textposition='outside')

    # Sector Distribution - Pie Chart
    sector_budget = df.groupby("sector")["budget"].sum().reset_index()
    pie_fig = px.pie(
        sector_budget,
        values="budget",
        names="sector",
        title="📊 Sector Distribution",
        height=350
    )
    pie_fig.update_layout(
        title_font_size=16,
        margin=dict(l=0, r=0, t=40, b=0)
    )
    pie_fig.update_traces(textinfo='percent+label', textposition='inside')

    # Performance Scatter Plot
    scatter_fig = px.scatter(
        df,
        x="budget",
        y="phi",
        color="region",
        size="gdpImpact",
        hover_name="project",
        title="🎯 Performance vs Investment",
        labels={"budget": "Budget (KSh)", "phi": "PHI Score", "gdpImpact": "GDP Impact"},
        height=350
    )
    scatter_fig.update_layout(
        title_font_size=16,
        margin=dict(l=0, r=0, t=40, b=0)
    )

    # Program Timeline
    program_timeline = df.groupby(["year", "program"]).size().reset_index(name="count")
    timeline_fig = px.bar(
        program_timeline,
        x="year",
        y="count",
        color="program",
        title="📅 Program Implementation Timeline",
        labels={"count": "Number of Projects", "year": "Year"},
        height=300
    )
    timeline_fig.update_layout(
        title_font_size=16,
        margin=dict(l=0, r=0, t=40, b=0)
    )

    return html.Div([
        # Top Row - Map and Budget Bars
        dbc.Row([
            dbc.Col(dcc.Graph(figure=map_fig), width=8),
            dbc.Col(dcc.Graph(figure=bar_fig), width=4)
        ], className="mb-3"),

        # Middle Row - Sector Pie and Performance Scatter
        dbc.Row([
            dbc.Col(dcc.Graph(figure=pie_fig), width=6),
            dbc.Col(dcc.Graph(figure=scatter_fig), width=6)
        ], className="mb-3"),

        # Bottom Row - Timeline
        dbc.Row([
            dbc.Col(dcc.Graph(figure=timeline_fig), width=12)
        ], className="mb-3"),

        # Footer Information
        html.Div([
            html.Hr(),
            html.P("Deric Marangu — Deriving Extreme Clarity for Stakeholders", className="text-center text-muted small"),
            html.P("🇰🇪 Powered by Kenyan Data. Built for Kenyan Impact.", className="text-center small"),
            html.P("*\"This dashboard reflects the heartbeat of Kenya — powered by data, driven by vision.\" — President William Ruto*", className="text-center font-italic text-warning small")
        ], className="mt-4")
    ])

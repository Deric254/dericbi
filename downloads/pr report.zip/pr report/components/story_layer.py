from dash import html
import random

def story_toggle(data):
    quotes = [
        "“We must ensure that no region is left behind. Every Kenyan deserves a fair share of development.” — President Ruto",
        "“The BETA programmes are about transforming lives — not just building infrastructure, but building hope.” — President Ruto",
        "“Kenya’s future lies in the hands of our youth. We must empower them with tools, skills, and opportunity.” — President Ruto",
        "“Every shilling must be accounted for. Development must be visible, measurable, and impactful.” — President Ruto",
        "“CBC is not just a curriculum — it’s a commitment to future-proofing our children.” — President Ruto",
        "“The Hustler Fund is about dignity, access, and economic justice for every Kenyan.” — President Ruto"
    ]

    impact_stories = [
        "In Ukambani, 3 boreholes changed 1,200 lives — see the ripple.",
        "In Nyeri, a Level 4 hospital upgrade reduced emergency response time by 40%.",
        "Through Hustler Fund, over 1 million Kenyans accessed microloans in under 6 months.",
        "CBC rollout trained 90,000 teachers and reached every county.",
        "NHIF reforms now cover dialysis in 47 counties — a game changer for rural families."
    ]

    selected_quote = random.choice(quotes)
    selected_story = random.choice(impact_stories)

    return html.Div([
        html.H4("Presidential Quotes & Impact Stories"),
        html.Div([
            html.Div(selected_quote, className="quote-box"),
            html.Div(selected_story, className="quote-box")
        ])
    ])

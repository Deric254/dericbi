// Custom JS for draggable floating insights window
document.addEventListener('DOMContentLoaded', function() {
    var el = document.getElementById('floating-insights');
    if (!el) return;
    var offsetX = 0, offsetY = 0, startX = 0, startY = 0, dragging = false;

    el.addEventListener('mousedown', function(e) {
        if (e.button !== 0) return;
        var t = e.target;
        if (t.closest('a,button,input,textarea,select')) return;
        dragging = true;
        startX = e.clientX;
        startY = e.clientY;
        offsetX = el.offsetLeft;
        offsetY = el.offsetTop;
        document.body.style.userSelect = 'none';
    });

    document.addEventListener('mousemove', function(e) {
        if (!dragging) return;
        var dx = e.clientX - startX;
        var dy = e.clientY - startY;
        el.style.left = (offsetX + dx) + 'px';
        el.style.top = (offsetY + dy) + 'px';
    });

    document.addEventListener('mouseup', function() {
        if (dragging) {
            dragging = false;
            document.body.style.userSelect = '';
        }
    });
});

import pandas as pd
import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output
import plotly.express as px
import plotly.graph_objects as go
import os
from datetime import timedelta

# -------------------------------
# Load Marketing Data
# -------------------------------
data_path = os.path.join("data", "marketing_data.csv")
df = pd.read_csv(data_path)

# Convert dates
df['Start_Date'] = pd.to_datetime(df['Start_Date'])
df['End_Date'] = pd.to_datetime(df['End_Date'])

# Extract temporal fields & derived metrics
df['Year'] = df['Start_Date'].dt.year
df['Month'] = df['Start_Date'].dt.strftime('%b')
df['Duration_Days'] = (df['End_Date'] - df['Start_Date']).dt.days.clip(lower=0)

# Per-campaign ROI ratio (for visuals: Revenue/Spend)
df['ROI_Ratio'] = (df['Revenue_Generated'] / df['Spend']).replace([pd.NA, pd.NaT], 0)
# Per-campaign ROI percent (for KPIs and filter): (Revenue - Spend)/Spend * 100
df['ROI_Pct'] = ((df['Revenue_Generated'] - df['Spend']) / df['Spend']).replace([pd.NA, pd.NaT], 0) * 100

# Classify ROI categories (assumption thresholds)
def classify_roi(v):
    if v >= 50:  # Big ROI >= 50%
        return 'Big ROI'
    if v >= 20:  # Medium ROI 20-50%
        return 'Medium ROI'
    return 'Small ROI'  # <20%

df['ROI_Category'] = df['ROI_Pct'].apply(classify_roi)

# -------------------------------
# Utility: Format Large Numbers
# -------------------------------
def format_number(num):
    if num >= 1_000_000_000:
        return f"{num/1_000_000_000:.2f}B"
    elif num >= 1_000_000:
        return f"{num/1_000_000:.2f}M"
    elif num >= 1_000:
        return f"{num/1_000:.1f}K"
    return str(round(num, 2))

# -------------------------------
# Initialize App
# -------------------------------
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.FLATLY])
# Add custom CSS for mobile responsiveness
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <style>
            /* Make graphs horizontally scrollable on small screens */
            @media (max-width: 600px) {
                .dash-graph, .js-plotly-plot {
                    min-width: 340px !important;
                    max-width: 100vw !important;
                    overflow-x: auto !important;
                }
                .card, .dbc-card, .dbc-card-body {
                    padding: 0.5rem !important;
                }
                h2, .fw-bold {
                    font-size: 1.1rem !important;
                }
                .sidebar {
                    padding: 0.5rem !important;
                }
                .text-center, .text-muted {
                    font-size: 0.95rem !important;
                }
            }
            /* Prevent horizontal scroll on body */
            body {
                overflow-x: hidden;
            }
            /* Make floating-insights more obviously draggable */
            #floating-insights {
                cursor: move !important;
                user-select: none;
            }
        </style>
        <script src="/assets/draggable_insights.js"></script>
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''
app.title = "Ten Year Marketing Campaign Dashboard Report"

# -------------------------------
# Layout
# -------------------------------
months_order = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

from dash import ctx

# Drill state: store selected year for ROI chart
app.layout = dbc.Container([
    # Floating insights window (hidden by default, shown via JS)
    html.Div([
        html.Div(id='insights_output_floating', style={"marginTop": "0px"})
    ], id='floating-insights', style={
        "position": "absolute",
        "top": "100px",
        "left": "auto",
        "right": "40px",
        "zIndex": 9999,
        "boxShadow": "0 2px 8px rgba(40,53,147,0.18)",
        "borderRadius": "8px",
        "minWidth": "320px",
        "maxWidth": "480px",
        "background": "#fffbe6",
        "cursor": "move"
    }),
    dcc.Store(id='roi_drill_state', data={'level': 'year', 'year': None}),
    dbc.Row([
        dbc.Col(
            html.A(
                html.Img(
                    src=dash.get_asset_url("Golden _X_ Logo Design.png"),
                    style={
                        "width": "clamp(40px, 8vw, 50px)",
                        "height": "clamp(40px, 8vw, 50px)",
                        "borderRadius": "50%",
                        "marginRight": "clamp(8px, 2vw, 10px)"
                    },
                    alt="Logo"
                ),
                href="https://exesbi.netlify.app",
                target="_blank"
            ),
            width="auto", xs=2, sm=2, md=1
        ),
        dbc.Col(html.H2(
            "Ten year marketing campaign dashboard report",
            className="fw-bold mt-3 mb-2 text-center",
            style={
                "color": "#fff",
                "fontWeight": "900",
                "letterSpacing": "1.5px",
                "textShadow": "0 2px 8px rgba(0,0,0,0.18)",
                "fontFamily": "Segoe UI, Arial, sans-serif"
            }), xs=10, sm=10, md=11)
    ], className="align-items-center mb-2", justify="between", style={"backgroundColor": "#1a237e", "borderRadius": "8px", "boxShadow": "0 2px 8px rgba(26,35,126,0.08)"}),
    dbc.Row([
        # Sidebar with deep color
        dbc.Col([
            html.H2("Filters", className="fw-bold mb-3", style={
                "color": "#fff",
                "fontWeight": "900",
                "letterSpacing": "1.2px",
                "textShadow": "0 2px 8px rgba(0,0,0,0.18)",
                "fontFamily": "Segoe UI, Arial, sans-serif"
            }),
            html.Div([
                html.H6("Month", className="fw-bold border-bottom pb-1", style={
                    "color": "#fff",
                    "fontWeight": "700",
                    "letterSpacing": "1px",
                    "textShadow": "0 1px 4px rgba(0,0,0,0.12)",
                    "fontFamily": "Segoe UI, Arial, sans-serif",
                    "fontSize": "1.3rem"
                }),
                dbc.Row([
                    dbc.Col([
                        dcc.Checklist(
                            id='month_filter_col1',
                            options=[{"label": m, "value": m} for m in months_order[:6] if m in df['Month'].unique()],
                            value=[],
                            inputStyle={"marginRight": "6px", "marginLeft": "2px", "transform": "scale(1.3)"},
                            labelStyle={"display": "block", "fontSize": "1.2rem", "color": "#fff", "fontWeight": "700", "letterSpacing": "0.5px", "marginBottom": "6px"}
                        )
                    ], width=6),
                    dbc.Col([
                        dcc.Checklist(
                            id='month_filter_col2',
                            options=[{"label": m, "value": m} for m in months_order[6:] if m in df['Month'].unique()],
                            value=[],
                            inputStyle={"marginRight": "6px", "marginLeft": "2px", "transform": "scale(1.3)"},
                            labelStyle={"display": "block", "fontSize": "1.2rem", "color": "#fff", "fontWeight": "700", "letterSpacing": "0.5px", "marginBottom": "6px"}
                        )
                    ], width=6)
                ], className="g-0"),
            ], className="mb-2"),
            html.Div([
                html.H6("Year", className="fw-bold border-bottom pb-1", style={
                    "color": "#fff",
                    "fontWeight": "700",
                    "letterSpacing": "1px",
                    "textShadow": "0 1px 4px rgba(0,0,0,0.12)",
                    "fontFamily": "Segoe UI, Arial, sans-serif",
                    "fontSize": "1.3rem"
                }),
                dbc.Row([
                    dbc.Col([
                        dcc.Checklist(
                            id='year_filter_col1',
                            options=[{"label": str(y), "value": y} for y in sorted(df['Year'].unique())[:len(sorted(df['Year'].unique()))//2]],
                            value=[],
                            inputStyle={"marginRight": "6px", "marginLeft": "2px", "transform": "scale(1.3)"},
                            labelStyle={"display": "block", "fontSize": "1.2rem", "color": "#fff", "fontWeight": "700", "letterSpacing": "0.5px", "marginBottom": "6px"}
                        )
                    ], width=6),
                    dbc.Col([
                        dcc.Checklist(
                            id='year_filter_col2',
                            options=[{"label": str(y), "value": y} for y in sorted(df['Year'].unique())[len(sorted(df['Year'].unique()))//2:]],
                            value=[],
                            inputStyle={"marginRight": "6px", "marginLeft": "2px", "transform": "scale(1.3)"},
                            labelStyle={"display": "block", "fontSize": "1.2rem", "color": "#fff", "fontWeight": "700", "letterSpacing": "0.5px", "marginBottom": "6px"}
                        )
                    ], width=6)
                ], className="g-0"),
            ], className="mb-3"),
            html.Div([
                html.H6("ROI", className="fw-bold border-bottom pb-1", style={
                    "color": "#fff",
                    "fontWeight": "700",
                    "letterSpacing": "1px",
                    "textShadow": "0 1px 4px rgba(0,0,0,0.12)",
                    "fontFamily": "Segoe UI, Arial, sans-serif",
                    "fontSize": "1.3rem"
                }),
                dcc.Checklist(
                    id='roi_filter',
                    options=[{"label": cat, "value": cat} for cat in ['Big ROI','Medium ROI','Small ROI']],
                    value=[],
                    inputStyle={"marginRight": "6px", "marginLeft": "2px", "transform": "scale(1.3)"},
                    labelStyle={"display": "block", "fontSize": "1.2rem", "color": "#fff", "fontWeight": "700", "letterSpacing": "0.5px", "marginBottom": "6px"}
                )
            ], className="mb-3"),
            html.Div([
                html.P("Developed by", className="mb-1 fw-bold", style={
                    "fontSize": "1.1rem", "color": "#fff", "fontWeight": "700", "letterSpacing": "0.5px", "textShadow": "0 1px 4px rgba(0,0,0,0.12)", "fontFamily": "Segoe UI, Arial, sans-serif"
                }),
                html.Span("Deric Marangu", style={"fontSize": "1rem", "display":"block", "color": "#fff", "fontWeight": "600", "letterSpacing": "0.5px", "marginBottom": "2px"}),
                html.A("exesbi.netlify.app", href="https://exesbi.netlify.app", target="_blank", id="exesbi-link", style={
                    "fontSize": "1rem", "display": "block", "color": "#fff", "fontWeight": "600", "letterSpacing": "0.5px", "textDecoration": "none", "transition": "color 0.2s"
                }),
                html.Span("whatsapp: +254791360805", style={"fontSize": "1rem", "color": "#fff", "fontWeight": "600", "letterSpacing": "0.5px", "display": "block", "marginBottom": "2px"}),
                html.Span("Email: dericmarangu@gmail.com", style={"fontSize": "1rem", "color": "#fff", "fontWeight": "600", "letterSpacing": "0.5px", "display": "block", "marginBottom": "8px"}),
                html.Button('Show Insights', id='insights_btn', n_clicks=0, className='btn btn-warning fw-bold', style={
                    'fontSize': '1.05rem', 'margin': '0 0 0 0', 'width': '100%', 'backgroundColor': '#FFD700', 'color': '#283593', 'border': 'none', 'borderRadius': '6px', 'boxShadow': '0 2px 8px rgba(40,53,147,0.08)', 'padding': '4px 0', 'minHeight': '32px'}
                ),
            ], className="mt-4"),
    ], xs=12, md=2, style={"backgroundColor": "#283593", "borderRadius": "8px", "boxShadow": "0 2px 8px rgba(40,53,147,0.08)", "minHeight": "100vh"}, className="border p-2 sidebar"),
        # Main content
        dbc.Col([
            # KPI Row
            dbc.Row([
                dbc.Col(dbc.Card(dbc.CardBody([
                    html.H6("Total campaigns", className="text-muted mb-1 text-center"),
                    html.H4(id='kpi_campaigns', className="fw-bold text-center text-primary")
                ])), md=2, xs=6, className="mb-2"),
                dbc.Col(dbc.Card(dbc.CardBody([
                    html.H6("Total spent", className="text-muted mb-1 text-center"),
                    html.H4(id='kpi_spend', className="fw-bold text-center text-primary")
                ])), md=2, xs=6, className="mb-2"),
                dbc.Col(dbc.Card(dbc.CardBody([
                    html.H6("AVG duration", className="text-muted mb-1 text-center"),
                    html.H4(id='kpi_avg_duration', className="fw-bold text-center text-primary")
                ])), md=2, xs=6, className="mb-2"),
                dbc.Col(dbc.Card(dbc.CardBody([
                    html.H6("Avg ROI (%)", className="text-muted mb-1 text-center"),
                    html.H4(id='kpi_roi', className="fw-bold text-center text-primary")
                ])), md=2, xs=6, className="mb-2"),
                dbc.Col(dbc.Card(dbc.CardBody([
                    html.H6("Total Revenue", className="text-muted mb-1 text-center"),
                    html.H4(id='kpi_revenue', className="fw-bold text-center text-success")
                ])), md=2, xs=6, className="mb-2"),
            ], justify="between", className="g-2"),
            # Figures grid (2 rows x 3)
            dbc.Row([
                dbc.Col(dcc.Graph(id='duration_area', config={'displayModeBar': False}, style={"height":420, "width": "100%"}), md=4, xs=12, className="mb-3"),
                dbc.Col([
                    dcc.Graph(id='annual_roi', config={'displayModeBar': False}, style={"height":420, "width": "100%"}),
                    html.Button('Back to Years', id='roi_back_btn', n_clicks=0, style={'display': 'none', 'marginTop': '5px'})
                ], md=4, xs=12, className="mb-3"),
                dbc.Col(dcc.Graph(id='revenue_channel', config={'displayModeBar': False}, style={"height":420, "width": "100%"}), md=4, xs=12, className="mb-3"),
            ]),
            dbc.Row([
                dbc.Col(dcc.Graph(id='spend_revenue_line', config={'displayModeBar': False}, style={"height":420, "width": "100%"}), md=4, xs=12, className="mb-3"),
                dbc.Col(dcc.Graph(id='spend_revenue_donut', config={'displayModeBar': False}, style={"height":420, "width": "100%"}), md=4, xs=12, className="mb-3"),
                dbc.Col(dcc.Graph(id='avg_roi_channel', config={'displayModeBar': False}, style={"height":420, "width": "100%"}), md=4, xs=12, className="mb-3"),
            ]),
            html.Div(
                "© 2025 EXES BI Analytics - All Rights Reserved",
                className="text-center mt-2",
                style={
                    "fontSize": "12px",
                    "backgroundColor": "#283593",
                    "color": "#fff",
                    "padding": "8px 0",
                    "borderRadius": "6px",
                    "marginTop": "12px",
                    "letterSpacing": "0.5px"
                }
            )
        ], xs=12, md=10)
    ])
], fluid=True, style={"padding":"10px", "backgroundColor":"#E6F0FA"})

# -------------------------------
# Callbacks
# -------------------------------
from dash.dependencies import State

@app.callback(
    [
        Output('duration_area', 'figure'),
        Output('annual_roi', 'figure'),
        Output('revenue_channel', 'figure'),
        Output('spend_revenue_line', 'figure'),
        Output('spend_revenue_donut', 'figure'),
        Output('avg_roi_channel', 'figure'),
        Output('kpi_campaigns', 'children'),
        Output('kpi_spend', 'children'),
        Output('kpi_avg_duration', 'children'),
        Output('kpi_roi', 'children'),
        Output('kpi_revenue', 'children'),
    Output('roi_back_btn', 'style'),
    Output('insights_output_floating', 'children'),
    ],
    [
        Input('month_filter_col1', 'value'),
        Input('month_filter_col2', 'value'),
        Input('year_filter_col1', 'value'),
        Input('year_filter_col2', 'value'),
        Input('roi_filter', 'value'),
        Input('roi_drill_state', 'data'),
    Input('insights_btn', 'n_clicks')
    ],
    [
    State('insights_output_floating', 'children')
    ]
)
def update_dashboard(months1, months2, years1, years2, selected_roi_cats, roi_drill_state, insights_clicks, insights_state):
    selected_months = (months1 or []) + (months2 or [])
    selected_years = (years1 or []) + (years2 or [])
    filtered_df = df.copy()

    if selected_months:
        filtered_df = filtered_df[filtered_df['Month'].isin(selected_months)]
    if selected_years:
        filtered_df = filtered_df[filtered_df['Year'].isin(selected_years)]
    if selected_roi_cats:
        filtered_df = filtered_df[filtered_df['ROI_Category'].isin(selected_roi_cats)]

    # KPIs
    total_campaigns = len(filtered_df)
    total_spend = filtered_df['Spend'].sum()
    total_revenue = filtered_df['Revenue_Generated'].sum()
    avg_duration = filtered_df['Duration_Days'].mean() if total_campaigns > 0 else 0
    avg_roi_pct = filtered_df['ROI_Pct'].mean() if total_campaigns > 0 else 0

    kpi_campaigns = format_number(total_campaigns)
    kpi_spend = format_number(total_spend)
    kpi_avg_duration = f"{avg_duration:.2f}" if avg_duration else "0"
    kpi_roi = f"{avg_roi_pct:.2f}%"
    kpi_revenue = format_number(total_revenue)

    # 1. Campaign duration vs Avg ROI (bin durations, area shaded, no markers)
    bins = [0, 5, 10, 15, 20, 25, 1000]
    labels = ['0-5', '6-10', '11-15', '16-20', '21-25', '26+']
    filtered_df['Duration_Bin'] = pd.cut(filtered_df['Duration_Days'], bins=bins, labels=labels, right=True, include_lowest=True)
    duration_group = filtered_df.groupby('Duration_Bin', observed=True)['ROI_Ratio'].mean().reset_index()
    y_min = duration_group['ROI_Ratio'].min()
    y_max = duration_group['ROI_Ratio'].max()
    margin = (y_max - y_min) * 0.1 if y_max > y_min else 0.1
    import plotly.graph_objects as go
    fig_duration = go.Figure()
    fig_duration.add_trace(go.Scatter(
        x=duration_group['Duration_Bin'],
        y=duration_group['ROI_Ratio'],
        mode='lines+markers',
        line=dict(color='#8FAADC', width=3),
        marker=dict(size=4, color='#8FAADC'),
        fill='tozeroy',
        fillcolor='rgba(40,53,147,0.18)',  # sidebar bg color with alpha
        name='Avg ROI'
    ))
    fig_duration.update_layout(
        margin=dict(l=10, r=10, t=40, b=30),
        yaxis_title='Average ROI',
        xaxis_title='campaign duration',
        yaxis_range=[y_min - margin, y_max + margin],
        title='Campaign duration',
        template='plotly_white'
    )

    # 2. Annual ROI line (drillable)
    if roi_drill_state and roi_drill_state.get('level') == 'month' and roi_drill_state.get('year'):
        # Drill: show monthly ROI for selected year (default line+markers)
        year = roi_drill_state['year']
        month_group = filtered_df[filtered_df['Year'] == year].groupby('Month')['ROI_Pct'].mean().reindex(months_order).reset_index()
        fig_annual = px.line(month_group, x='Month', y='ROI_Pct', markers=True, title=f'Monthly ROI for {year}',
                 template='plotly_white', color_discrete_sequence=['#005BA1'])
        fig_annual.update_xaxes(type='category')
        fig_annual.update_layout(margin=dict(l=10, r=10, t=40, b=30), yaxis_title='Return on investment')
        back_btn_style = {'display': 'block', 'marginTop': '5px'}
    else:
        annual_group = filtered_df.groupby('Year')['ROI_Pct'].mean().reset_index()
        fig_annual = px.line(annual_group, x='Year', y='ROI_Pct', markers=True, title='Annual ROI',
                 template='plotly_white', color_discrete_sequence=['#005BA1'])
        fig_annual.update_xaxes(type='category')  # Force x-axis to show only whole years
        fig_annual.update_layout(margin=dict(l=10, r=10, t=40, b=30), yaxis_title='Return on investment')
        back_btn_style = {'display': 'none'}

    # 3. Revenue generated (bar by channel, fix yaxis to autoexpand)
    channel_group = filtered_df.groupby('Channel')['Revenue_Generated'].sum().reset_index().sort_values('Revenue_Generated', ascending=False)
    fig_rev_channel = px.bar(
        channel_group, x='Channel', y='Revenue_Generated',
        text=[format_number(v) for v in channel_group['Revenue_Generated']],
        title='Revenue generated', template='plotly_white', color='Channel', color_discrete_sequence=px.colors.qualitative.Pastel
    )
    fig_rev_channel.update_traces(
        textposition='outside',
        cliponaxis=False,
        textfont=dict(size=36, color='#111', family='Segoe UI, Arial, sans-serif', weight='bold')  # Increased size
    )
    # Add extra y-axis padding to ensure labels are never cut off
    max_y = channel_group['Revenue_Generated'].max() if not channel_group.empty else 1
    fig_rev_channel.update_layout(
        margin=dict(l=10, r=10, t=40, b=30),
        showlegend=False,
        yaxis_title='Revenue Generated',
        yaxis=dict(automargin=True, rangemode='tozero',
                   range=[0, max_y * 1.28],  # 28% headroom for big label
                   tickfont=dict(size=16)),
    )

    # 4. Spending and revenue generated (cumulative line)
    spend_rev = filtered_df[['Spend','Revenue_Generated']].sort_values('Spend').copy()
    spend_rev['Cum_Spend'] = spend_rev['Spend'].cumsum()
    spend_rev['Cum_Revenue'] = spend_rev['Revenue_Generated'].cumsum()
    fig_spend_rev = go.Figure()
    fig_spend_rev.add_trace(go.Scatter(x=spend_rev['Cum_Spend'], y=spend_rev['Cum_Revenue'], mode='lines', line=dict(color='#005BA1', width=3)))
    fig_spend_rev.update_layout(title='Spending and revenue generated', template='plotly_white',
                margin=dict(l=10, r=10, t=40, b=30), xaxis_title='Spend', yaxis_title='Revenue_Generated')

    # 5. Spend vs Revenue donut
    total_values = {'Spend': total_spend, 'Revenue': total_revenue}
    fig_donut = go.Figure(data=[go.Pie(labels=list(total_values.keys()), values=list(total_values.values()), hole=.6,
                       textinfo='label+percent', marker=dict(colors=['#FFB900', '#0078D4']))])
    fig_donut.update_layout(title='Adspend :Revenue generated', template='plotly_white', margin=dict(l=10, r=10, t=40, b=30))

    # 6. Average ROI by Channel (area+small markers, dynamic y-axis with logical ticks)
    roi_channel = filtered_df.groupby('Channel')['ROI_Ratio'].mean().reset_index().sort_values('ROI_Ratio', ascending=False)
    y_min2 = roi_channel['ROI_Ratio'].min()
    y_max2 = roi_channel['ROI_Ratio'].max()
    if y_max2 > y_min2:
        y_min2_p = float(int(y_min2 * 10) / 10) - 0.05
        y_max2_p = float(int(y_max2 * 10 + 1) / 10) + 0.05
        n_ticks = 4
        step = (y_max2_p - y_min2_p) / (n_ticks - 1)
        ticks = [round(y_min2_p + i * step, 2) for i in range(n_ticks)]
    else:
        y_min2_p = y_min2 - 0.1
        y_max2_p = y_max2 + 0.1
        ticks = [round(y_min2, 2)]
    fig_avg_roi_channel = go.Figure()
    fig_avg_roi_channel.add_trace(go.Scatter(
        x=roi_channel['Channel'],
        y=roi_channel['ROI_Ratio'],
        mode='lines+markers',
        line=dict(color='#9DC3E6', width=3),
        marker=dict(size=4, color='#9DC3E6'),
        fill='tozeroy',
        fillcolor='rgba(40,53,147,0.18)',  # sidebar bg color with alpha
        name='Avg ROI'
    ))
    fig_avg_roi_channel.update_layout(
        margin=dict(l=10, r=10, t=40, b=30),
        yaxis_title='ROI',
        yaxis=dict(tickvals=ticks, range=[y_min2_p, y_max2_p]),
        title='Average ROI',
        template='plotly_white'
    )

    # Insights logic
    # Collapsible insights logic
    show_insights = False
    if insights_clicks and insights_clicks % 2 == 1:
        show_insights = True
    insights = None
    if show_insights:
        # Top 3 channels by ROI
        top_channels = roi_channel.head(3)
        top_channels_list = [
            html.Span([
                html.Span("🏆 ", style={"fontSize": "1.2em"}),
                html.Span(row['Channel'], style={"fontWeight": "bold", "color": "#283593"}),
                html.Span(f" (ROI: {row['ROI_Ratio']:.2f})", style={"color": "#444"})
            ], style={"display": "block", "marginBottom": "4px"})
            for _, row in top_channels.iterrows()
        ] if not top_channels.empty else [html.Span("N/A")]
        # Best campaign duration bin
        if not duration_group.empty:
            best_bin = duration_group.loc[duration_group['ROI_Ratio'].idxmax()]['Duration_Bin']
            best_bin_val = duration_group['ROI_Ratio'].max()
            best_bin_str = html.Span([
                html.Span("⏱️ ", style={"fontSize": "1.2em"}),
                html.Span(f"{best_bin}", style={"fontWeight": "bold", "color": "#283593"}),
                html.Span(f" (Avg ROI: {best_bin_val:.2f})", style={"color": "#444"})
            ])
        else:
            best_bin_str = html.Span("N/A")
        # Best year by ROI
        if not filtered_df.empty:
            best_year = filtered_df.groupby('Year')['ROI_Pct'].mean().idxmax()
            best_year_val = filtered_df.groupby('Year')['ROI_Pct'].mean().max()
            best_year_str = html.Span([
                html.Span("📅 ", style={"fontSize": "1.2em"}),
                html.Span(f"{best_year}", style={"fontWeight": "bold", "color": "#283593"}),
                html.Span(f" (Avg ROI: {best_year_val:.2f}%)", style={"color": "#444"})
            ])
        else:
            best_year_str = html.Span("N/A")
        insights = html.Div([
            html.Div([
                html.Span("✨ Actionable Insights", style={"color": "#283593", "fontWeight": "bold", "fontSize": "1.25rem", "letterSpacing": "0.5px"}),
            ], style={"marginBottom": "12px", "display": "block"}),
            html.Div([
                html.Div([html.Span("Top 3 Channels by ROI:", style={"fontWeight": "600", "color": "#222"})] + top_channels_list, style={"marginBottom": "10px"}),
                html.Div([html.Span("Best Campaign Duration:", style={"fontWeight": "600", "color": "#222"}), best_bin_str], style={"marginBottom": "10px"}),
                html.Div([html.Span("Best Year for ROI:", style={"fontWeight": "600", "color": "#222"}), best_year_str], style={"marginBottom": "10px"}),
            ], style={"fontSize": "1.1rem", "color": "#222", "fontWeight": "600", "lineHeight": "2"}),
            html.P("Use filters to refine insights for specific months, years, or ROI categories.", style={'fontSize': '1rem', 'color': '#555', 'marginTop': '8px'})
        ], style={'background': '#fffbe6', 'border': '2px solid #FFD700', 'borderRadius': '8px', 'padding': '18px', 'marginTop': '8px', 'boxShadow': '0 2px 8px rgba(40,53,147,0.08)', 'maxWidth': '480px', 'marginLeft': 'auto', 'marginRight': 'auto'})
    return (fig_duration, fig_annual, fig_rev_channel, fig_spend_rev, fig_donut, fig_avg_roi_channel,
        kpi_campaigns, kpi_spend, kpi_avg_duration, kpi_roi, kpi_revenue, back_btn_style, insights)

# Drilldown callback: click on year to drill to month, back button to return
@app.callback(
    Output('roi_drill_state', 'data'),
    [Input('annual_roi', 'clickData'), Input('roi_back_btn', 'n_clicks')],
    prevent_initial_call=True
)
def drill_roi(clickData, back_clicks):
    triggered = ctx.triggered_id
    if triggered == 'annual_roi' and clickData:
        # Drill to month for selected year
        year = clickData['points'][0]['x']
        try:
            year = int(year)
        except Exception:
            pass
        return {'level': 'month', 'year': year}
    elif triggered == 'roi_back_btn':
        # Go back to year view
        return {'level': 'year', 'year': None}
    return dash.no_update

# -------------------------------
# Run Server
# -------------------------------
if __name__ == '__main__':
    app.run(debug=True)
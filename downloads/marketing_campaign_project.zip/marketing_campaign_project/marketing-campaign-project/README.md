# marketing campaign project
marketing campaign dashboard report is a portfolio project showcasing my data analytic skills using modern tools 

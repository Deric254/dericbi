# ============================================================
# NGO IMPACT TRACKER DASHBOARD (Clean Final Version)
# Author: Deric Marangu | DericBI
# ============================================================

import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import base64
import io
from flask import Response, request
import os

# ---------- CONFIG ----------
# Use a relative path so the dataset can live inside the project (assets folder)
DATA_PATH = r"./assets/impact_tracker_data.csv"

# ---------- LOAD DATA ----------
df = pd.read_csv(DATA_PATH, parse_dates=['Activity_Date'], dayfirst=True)
df['Year'] = df['Activity_Date'].dt.year
df['Month'] = df['Activity_Date'].dt.strftime('%b')

# ---------- INIT APP ----------
app = dash.Dash(__name__)
app.title = "DericBI | NGO Impact Tracker"

# ---------- COLORS ----------
PRIMARY = "#00695C"
SECONDARY = "#00ACC1"
BACKGROUND = "#FAFAFA"

# ---------- KPI FUNCTION ----------
def compute_kpis(filtered):
    total_projects = filtered["Project_ID"].nunique()
    completed_projects = filtered[filtered['Project_Status'] == 'Completed']['Project_ID'].nunique()
    completion_rate = round((completed_projects / total_projects) * 100, 1) if total_projects > 0 else 0
    
    return {
        "projects": total_projects,
        "beneficiaries": filtered["Beneficiary_ID"].nunique(),
        "budget": filtered["Project_Budget"].sum(),
        "impact": round(filtered["Impact_Score"].mean(), 1),
        "training": round(filtered["Training_Hours"].mean(), 1),
        "completion_rate": completion_rate
    }


def format_currency_short(n):
    """Format number into short currency form with suffixes.

    Examples:
      1234 -> 'KSh 1.23K'
      5_600_000 -> 'KSh 5.60M'
      7_890_000_000 -> 'KSh 7.89B'
      1_200_000_000_000 -> 'KSh 1.20T'
    """
    try:
        n = float(n)
    except Exception:
        return f"KSh {n}"

    abs_n = abs(n)
    if abs_n >= 1e12:
        val = n / 1e12
        suffix = 'T'
    elif abs_n >= 1e9:
        val = n / 1e9
        suffix = 'B'
    elif abs_n >= 1e6:
        val = n / 1e6
        suffix = 'M'
    elif abs_n >= 1e3:
        val = n / 1e3
        suffix = 'K'
    else:
        return f"KSh {int(n):,}"

    # Show two decimal places, drop trailing zeros
    s = f"{val:,.2f}".rstrip('0').rstrip('.')
    return f"KSh {s}{suffix}"


def number_short(n):
    """Format a raw number with suffixes (no currency prefix).

    Examples:
      1234 -> '1.23K'
      5_600_000 -> '5.6M'
      7_890_000_000 -> '7.89B'
    """
    try:
        n = float(n)
    except Exception:
        return str(n)

    abs_n = abs(n)
    if abs_n >= 1e12:
        val = n / 1e12
        suffix = 'T'
    elif abs_n >= 1e9:
        val = n / 1e9
        suffix = 'B'
    elif abs_n >= 1e6:
        val = n / 1e6
        suffix = 'M'
    elif abs_n >= 1e3:
        val = n / 1e3
        suffix = 'K'
    else:
        # For small integers, show as integer with commas
        if float(n).is_integer():
            return f"{int(n):,}"
        return f"{n}"

    s = f"{val:,.2f}".rstrip('0').rstrip('.')
    return f"{s}{suffix}"


def first_word(s):
    """Return the first word of a string for compact labels."""
    try:
        return str(s).split()[0]
    except Exception:
        return str(s)

# ---------- STYLES ----------
CARD_STYLE = {
    'backgroundColor': '#FFFFFF',
    'borderRadius': '8px',
    'padding': '10px',
    'boxShadow': '0 2px 4px rgba(0,0,0,0.08)',
    'textAlign': 'center',
    'flex': '1',
    'margin': '3px'
}

# ---------- LAYOUT ----------
app.layout = html.Div([
    # HEADER with logo (logo placed left; title centered)
    html.Div([
                                html.Div([
                                        html.A(html.Img(src=app.get_asset_url('logo.png'),
                                                         style={'display':'block', 'margin':'0 auto'}),
                                                     href='https://dericbi.netlify.app/my-projects', target='_blank'),
                                ], className='header-logo', style={'flex':'0 0 230px', 'display':'flex', 'alignItems':'center', 'justifyContent':'center'}),

        html.Div([
            html.H1("📊 DericBI NGO Impact Tracker", 
                    style={'textAlign': 'center', 'color': PRIMARY, 'marginBottom': '0'}),
            html.P("Empowering NGOs with Data-Driven Insights | dericmarangu@gmail.com | dericbi.netlify.app/my-projects",
                   style={'textAlign': 'center', 'color': '#444', 'marginTop': '2px', 'fontSize': '13px'})
        ], style={'flex':'1', 'display':'flex', 'flexDirection':'column', 'justifyContent':'center'}),

    # empty spacer to keep title centered between logo and this spacer
    html.Div(style={'flex':'0 0 230px'}),

        # Right header: fancy report generation button (does not displace layout)
        html.Div(html.A([
            html.Span("📄", className='icon'),
            html.Span("Download Report")
        ], href='/download', target='_blank', className='report-button'),
                 style={'flex':'0 0 230px', 'display':'flex', 'alignItems':'center', 'justifyContent':'center'})
    ], style={
        'backgroundColor': '#E0F2F1',
        'padding': '10px',
        'borderBottom': f'3px solid {PRIMARY}',
        'boxShadow': '0 2px 6px rgba(0,0,0,0.1)',
        'display':'flex',
        'alignItems':'center'
    }),

    html.Div([
        # FILTER PANEL
        html.Div([
            html.H3("Filters", style={'color': PRIMARY, 'marginBottom': '8px'}),
            html.Label("Sector"), dcc.Dropdown(id='sector-filter',
                options=[{'label': s, 'value': s} for s in sorted(df['Sector'].unique())],
                multi=True, placeholder='Select Sector', style={'fontSize':'14px'}),

            html.Label("County"), dcc.Dropdown(id='county-filter',
                options=[{'label': c, 'value': c} for c in sorted(df['County'].unique())],
                multi=True, placeholder='Select County', style={'fontSize':'14px'}),

            html.Label("Donor"), dcc.Dropdown(id='donor-filter',
                options=[{'label': d, 'value': d} for d in sorted(df['Donor'].unique())],
                multi=True, placeholder='Select Donor', style={'fontSize':'14px'}),

            html.Label("Project Status"), dcc.Dropdown(id='status-filter',
                options=[{'label': s, 'value': s} for s in sorted(df['Project_Status'].unique())],
                multi=True, placeholder='Select Status', style={'fontSize':'14px'}),

            html.Div([
                html.Hr(),
                html.P("Built by DericBI", style={'fontWeight':'bold','margin':'0'}),
                html.P("📧 dericmarangu@gmail.com", style={'fontSize':'12px','margin':'0'}),
                html.A("🌐 dericbi.netlify.app/my-projects",
                    href="https://dericbi.netlify.app/my-projects", target="_blank",
                    style={'fontSize':'12px','color':PRIMARY}),
                # Larger clickable logo below the slicers that links to the site
          html.Div(html.A(html.Img(src=app.get_asset_url('logo.png'),
                          style={'display':'block','margin':'8px auto'}),
                    href='https://dericbi.netlify.app/my-projects', target='_blank'),
                className='sidebar-logo', style={'marginTop':'12px','textAlign':'center'})
            ], style={'marginTop':'30px','textAlign':'center'})
        ], style={
            'flex': '0 0 230px',
            'backgroundColor': '#E0F2F1',
            'padding': '12px',
            'borderRight': f'3px solid {PRIMARY}',
            'boxSizing': 'border-box'
        }),

        # MAIN CONTENT
        html.Div([
            html.Div(id='kpi-cards',
                     style={'display':'flex','justifyContent':'space-between',
                            'padding':'6px 10px','flexWrap':'wrap'}),

            html.Div([
                html.Div(dcc.Graph(id='bar-sector', config={'displayModeBar': False}), className='chart-card'),
                    html.Div(dcc.Graph(id='line-activity', config={'displayModeBar': False}), className='chart-card'),
                    html.Div(dcc.Graph(id='pie-budget', config={'displayModeBar': False}), className='chart-card'),
                    html.Div(dcc.Graph(id='scatter-impact', config={'displayModeBar': False}), className='chart-card'),
                    html.Div(dcc.Graph(id='map-county', config={'displayModeBar': False}), className='chart-card'),
                    html.Div(dcc.Graph(id='hist-age', config={'displayModeBar': False}), className='chart-card')
            ], style={
                'display':'grid',
                'gridTemplateColumns':'repeat(3, 1fr)',
                'gridGap':'10px',
                # add extra bottom padding to avoid last-row clipping in small viewports
                'padding':'0 10px 30px 10px'
            })
        ], style={
            'flex': '1',
            'backgroundColor': BACKGROUND,
            'padding': '8px',
            # extra bottom padding so charts at the bottom aren't clipped by viewport
            'paddingBottom': '24px',
            'overflowY': 'auto',
            'height': '92vh',
            'boxSizing': 'border-box'
        })
    ], style={
        'display': 'flex',
        'height': 'calc(100vh - 90px)',
        'overflow': 'hidden'
    })
])


# (Report route moved below update_dashboard to avoid forward-reference issues with static analysis)

# Helper to build the HTML report (returns HTML string)
def generate_report_html(include_interactive_fallback=True):
    """Generate HTML report string. If image export fails, optionally embed interactive Plotly snippets as a fallback.

    Returns: page (str)
    """
    # Reuse the existing dashboard update function to get the figures and KPIs
    kpi_cards, bar_fig, line_fig, pie_fig, scatter_fig, map_fig, hist_fig = update_dashboard(None, None, None, None)

    figs = [
        ("Projects by Sector", bar_fig),
        ("Monthly Activities Trend", line_fig),
        ("Budget Allocation by Sector", pie_fig),
        ("Impact vs Training Hours", scatter_fig),
        ("Beneficiaries by County", map_fig),
        ("Age Distribution", hist_fig)
    ]

    # Convert figures to PNG and base64-encode them for embedding.
    # If static image export fails, optionally include an interactive HTML snippet.
    images = {}
    for title, fig in figs:
        png_b64 = ''
        html_snippet = ''
        try:
            # Prefer kaleido as the engine for static image export
            img_bytes = fig.to_image(format='png', engine='kaleido', scale=2)
            if img_bytes:
                png_b64 = base64.b64encode(img_bytes).decode('utf-8')
        except Exception:
            # Fallback: if allowed, include an interactive fragment instead
            if include_interactive_fallback:
                try:
                    html_snippet = fig.to_html(full_html=False, include_plotlyjs='cdn')
                except Exception:
                    html_snippet = ''
        images[title] = {'png': png_b64, 'html': html_snippet}

        # Ensure logo is embedded as a data URI so the report shows the logo even when
        # the HTML is downloaded and opened offline or converted to PDF.
        try:
            logo_path = os.path.join(os.path.dirname(__file__), 'assets', 'logo.png')
            if os.path.exists(logo_path):
                with open(logo_path, 'rb') as f:
                    logo_b = f.read()
                logo_b64 = base64.b64encode(logo_b).decode('utf-8')
                logo_src = f"data:image/png;base64,{logo_b64}"
            else:
                logo_src = '/assets/logo.png'
        except Exception:
            logo_src = '/assets/logo.png'

    # Generate top-level KPIs and some automated insights
    k = compute_kpis(df)

    top_sectors = df.groupby('Sector').size().nlargest(3)
    top_sectors_text = ", ".join([f"{idx} ({v} projects)" for idx, v in top_sectors.items()]) if not top_sectors.empty else 'n/a'

    top_counties = df.groupby('County')['Beneficiary_ID'].nunique().nlargest(3)
    top_counties_text = ", ".join([f"{idx} ({v} beneficiaries)" for idx, v in top_counties.items()]) if not top_counties.empty else 'n/a'

    try:
        monthly = df.set_index('Activity_Date').resample('M').size()
        recent = monthly.dropna().astype(int)
        mom_text = 'No trend data'
        if len(recent) >= 2:
            last = recent.iloc[-1]
            prev = recent.iloc[-2]
            pct = round((last - prev) / prev * 100, 1) if prev != 0 else 0
            mom_text = f"Last month {last} activities ({pct}% vs previous month)"
    except Exception:
        mom_text = 'Trend unavailable'

    # Build HTML (kept largely the same as before, but use new images mapping)
    html_parts = []
    html_parts.append("""
    <!doctype html>
    <html lang='en'>
    <head>
        <meta charset='utf-8'/>
        <meta name='viewport' content='width=device-width, initial-scale=1'/>
        <title>DericBI - NGO Impact Report</title>
        <link rel='stylesheet' href='/assets/style.css'>
        <style>
            body{font-family:Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial; margin:24px; color:#222}
            .report-header{display:flex;align-items:center;justify-content:space-between;border-bottom:3px solid #00695C;padding-bottom:12px}
            .brand{display:flex;align-items:center;gap:12px}
            .brand img{height:64px}
            .report-meta{color:#555}
            .kpi-grid{display:flex;gap:12px;margin-top:16px}
            .kpi{flex:1;background:#fff;padding:14px;border-radius:10px;box-shadow:0 8px 20px rgba(0,0,0,0.06);}
            .section{margin-top:22px}
            h2{color:#00695C;margin-bottom:8px}
            .chart-img{width:100%;max-width:900px;border-radius:8px;box-shadow:0 8px 30px rgba(0,0,0,0.06)}
            .insights{background:#f7fffb;border-left:6px solid #00BFA5;padding:12px;border-radius:6px}
            .footer{margin-top:36px;color:#666;font-size:13px}
        </style>
    </head>
    <body>
    """)

    # Header
    html_parts.append(f"""
    <div class='report-header'>
        <div class='brand'>
            <img src='{logo_src}' alt='DericBI logo'/>
            <div>
                <h1 style='margin:0;color:#00695C'>DericBI - NGO Impact Report</h1>
                <div class='report-meta'>Automatically generated report • {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}</div>
            </div>
        </div>
        <div style='text-align:right'>
            <a class='report-button' href='https://dericbi.netlify.app/my-projects' target='_blank' rel='noopener noreferrer' style='text-decoration:none;'>Open Dashboard</a>
        </div>
    </div>
    """)

    # KPI cards
    html_parts.append("""
    <div class='kpi-grid'>
    """)
    html_parts.append(f"<div class='kpi'><h3 style='margin:0;color:#00695C'>{k['projects']:,}</h3><div>Projects</div></div>")
    html_parts.append(f"<div class='kpi'><h3 style='margin:0;color:#00695C'>{k['beneficiaries']:,}</h3><div>Beneficiaries</div></div>")
    html_parts.append(f"<div class='kpi'><h3 style='margin:0;color:#00695C'>{format_currency_short(k['budget'])}</h3><div>Total Budget</div></div>")
    html_parts.append(f"<div class='kpi'><h3 style='margin:0;color:#00695C'>{k['impact']}</h3><div>Avg Impact</div></div>")
    html_parts.append(f"<div class='kpi'><h3 style='margin:0;color:#00695C'>{k['training']}</h3><div>Avg Training Hrs</div></div>")
    html_parts.append(f"<div class='kpi'><h3 style='margin:0;color:#00695C'>{k['completion_rate']}%</h3><div>Completion Rate</div></div>")
    html_parts.append("</div>")

    # Insights & summary
    html_parts.append("""
    <div class='section'>
        <h2>Executive Summary</h2>
        <div class='insights'>
    """)
    html_parts.append(f"<p><strong>Top sectors by projects:</strong> {top_sectors_text}</p>")
    html_parts.append(f"<p><strong>Top counties by beneficiaries:</strong> {top_counties_text}</p>")
    html_parts.append(f"<p><strong>Recent activity trend:</strong> {mom_text}</p>")
    html_parts.append("</div></div>")

    # Charts
    html_parts.append("<div class='section'><h2>Charts & Visuals</h2>")
    for title, data in images.items():
        safe_title = title.replace('"', '')
        png = data.get('png')
        html_snip = data.get('html')
        html_parts.append(f"<div style='margin-top:14px'><h3 style='margin:6px 0'>{safe_title}</h3>")
        if png:
            html_parts.append(f"<img class='chart-img' src='data:image/png;base64,{png}' alt='{safe_title}'/>")
        elif html_snip:
            # Wrap interactive snippet in a responsive container
            html_parts.append("<div style='max-width:900px;background:#fff;padding:8px;border-radius:8px;'>")
            html_parts.append(html_snip)
            html_parts.append("</div>")
        else:
            html_parts.append("<div style='padding:14px;background:#fff;border-radius:6px;color:#777'>Image not available</div>")
        html_parts.append("</div>")
    html_parts.append("</div>")

    # Recommendations & conclusions
    html_parts.append("""
    <div class='section'>
        <h2>Recommendations</h2>
        <ol>
            <li>Prioritize funding to the top 3 sectors identified and monitor ROI via impact score quarterly.</li>
            <li>Deploy targeted beneficiary programs in top counties to maximize reach and efficiency.</li>
            <li>Investigate projects with below-average training hours but high impact for potential replication.</li>
            <li>Set a target to improve completion rate by 5% within the next 12 months and track via monthly dashboards.</li>
        </ol>
    </div>

    <div class='section'>
        <h2>Conclusions</h2>
        <p>The data shows clear concentration of activities in the sectors and counties listed above. Use the dashboard filters to explore details and the downloadable charts in this report for presentations to stakeholders.</p>
    </div>

    <div class='footer'>
        <div>Prepared by DericBI • dericmarangu@gmail.com • dericbi.netlify.app/my-projects</div>
    </div>
    </body></html>
    """)

    page = '\n'.join(html_parts)
    return page


@app.server.route('/report')
def report():
    """Return the report as an HTML page (viewable in browser)."""
    try:
        page = generate_report_html(include_interactive_fallback=True)
        return Response(page, mimetype='text/html')
    except Exception as e:
        return Response(f"<pre>Report generation failed:\n{e}</pre>", mimetype='text/html')


@app.server.route('/download')
def download_report():
    """Attempt to return a downloadable PDF; fall back to an HTML attachment if PDF conversion is unavailable.

    The route returns a file attachment so users can save the report locally.
    """
    try:
        page = generate_report_html(include_interactive_fallback=True)

        # Try to generate a PDF if pdfkit and wkhtmltopdf are available
        try:
            import pdfkit
            # Generate PDF bytes. If wkhtmltopdf is not installed, this will raise an OSError
            pdf_bytes = pdfkit.from_string(page, False)
            headers = {
                'Content-Type': 'application/pdf',
                'Content-Disposition': 'attachment; filename="NGO-impact-report.pdf"'
            }
            return Response(pdf_bytes, headers=headers)
        except Exception:
            # Fallback to downloadable HTML file
            headers = {
                'Content-Type': 'text/html',
                'Content-Disposition': 'attachment; filename="NGO-impact-report.html"'
            }
            return Response(page, headers=headers)

    except Exception as e:
        return Response(f"<pre>Download failed:\n{e}</pre>", mimetype='text/html')
@app.callback(
    [Output('kpi-cards', 'children'),
     Output('bar-sector', 'figure'),
     Output('line-activity', 'figure'),
     Output('pie-budget', 'figure'),
     Output('scatter-impact', 'figure'),
     Output('map-county', 'figure'),
     Output('hist-age', 'figure')],
    [Input('sector-filter','value'),
     Input('county-filter','value'),
     Input('donor-filter','value'),
     Input('status-filter','value')]
)
def update_dashboard(sector, county, donor, status):
    filtered = df.copy()
    if sector: filtered = filtered[filtered['Sector'].isin(sector)]
    if county: filtered = filtered[filtered['County'].isin(county)]
    if donor: filtered = filtered[filtered['Donor'].isin(donor)]
    if status: filtered = filtered[filtered['Project_Status'].isin(status)]

    # Create short label columns (first word only) to keep chart labels compact
    # Use .astype(str) to avoid issues with NaN
    filtered['Sector_short'] = filtered['Sector'].astype(str).apply(first_word)
    # Project_Name and County may be used in hover info; shorten them too
    if 'Project_Name' in filtered.columns:
        filtered['Project_Name_short'] = filtered['Project_Name'].astype(str).apply(first_word)
    else:
        filtered['Project_Name_short'] = ''
    if 'County' in filtered.columns:
        filtered['County_short'] = filtered['County'].astype(str).apply(first_word)
    else:
        filtered['County_short'] = ''

    # Create short numeric labels for use in hover/text (no currency prefix)
    if 'Training_Hours' in filtered.columns:
        filtered['Training_label'] = filtered['Training_Hours'].apply(number_short)
    else:
        filtered['Training_label'] = ''
    if 'Project_Budget' in filtered.columns:
        # budget label with currency
        filtered['Project_Budget_label'] = filtered['Project_Budget'].apply(format_currency_short)
    else:
        filtered['Project_Budget_label'] = ''

    k = compute_kpis(filtered)
    kpi_cards = [
        html.Div([html.H3(f"{k['projects']:,}", style={'color':PRIMARY,'margin':'0'}),
                  html.P("Projects", style={'margin':'0'})], style=CARD_STYLE),
        html.Div([html.H3(f"{k['beneficiaries']:,}", style={'color':PRIMARY,'margin':'0'}),
                  html.P("Beneficiaries", style={'margin':'0'})], style=CARD_STYLE),
    html.Div([html.H3(format_currency_short(k['budget']), style={'color':PRIMARY,'margin':'0'}),
          html.P("Total Budget", style={'margin':'0'})], style=CARD_STYLE),
        html.Div([html.H3(f"{k['impact']}", style={'color':PRIMARY,'margin':'0'}),
                  html.P("Avg Impact", style={'margin':'0'})], style=CARD_STYLE),
        html.Div([html.H3(f"{k['training']}", style={'color':PRIMARY,'margin':'0'}),
                  html.P("Avg Training Hrs", style={'margin':'0'})], style=CARD_STYLE),
        html.Div([html.H3(f"{k['completion_rate']}%", style={'color':PRIMARY,'margin':'0'}),
                  html.P("Completion Rate", style={'margin':'0'})], style=CARD_STYLE)
    ]

    common_layout = dict(
        margin=dict(l=30, r=20, t=35, b=30),
        font=dict(size=11),
        height=320,
        plot_bgcolor="#FFFFFF",
        paper_bgcolor="#FFFFFF"
    )

    # BAR
    bar_data = filtered.groupby("Sector").size().reset_index(name="Projects")
    # keep grouping by full Sector but display a compact label
    bar_data['Sector_short'] = bar_data['Sector'].apply(first_word)
    # short label for projects
    bar_data['Projects_label'] = bar_data['Projects'].apply(number_short)
    # Show project counts as labels on bars and keep full sector name in hover
    bar_fig = px.bar(bar_data, x="Projects", y="Sector_short", orientation='h',
                     color="Sector_short", text='Projects',
                     title="Projects by Sector", hover_data=['Sector', 'Projects_label'])
    # place labels automatically (inside when space allows)
    bar_fig.update_traces(textposition='auto', textfont_size=12,
                          hovertemplate='<b>%{customdata[0]}</b><br>Projects: %{customdata[1]}')
    bar_fig.update_layout(**common_layout, showlegend=False, title_x=0.5)

    # LINE
    trend = filtered.groupby(filtered['Activity_Date'].dt.to_period('M')).size().reset_index(name='Activities')
    trend['Month'] = trend['Activity_Date'].astype(str)
    line_fig = px.line(trend, x='Month', y='Activities', markers=True, title="Monthly Activities Trend")
    line_fig.update_traces(line_color=PRIMARY)
    line_fig.update_layout(**common_layout, title_x=0.5)

    # PIE
    pie_data = filtered.groupby("Sector")["Project_Budget"].sum().reset_index()
    pie_data['Sector_short'] = pie_data['Sector'].apply(first_word)
    pie_data['Project_Budget_label'] = pie_data['Project_Budget'].apply(format_currency_short)
    pie_fig = px.pie(pie_data, names='Sector_short', values='Project_Budget', hole=0.35,
                     title="Budget Allocation by Sector", hover_data=['Sector','Project_Budget_label'])
    pie_fig.update_traces(textinfo='percent', textfont_size=10,
                         hovertemplate='<b>%{customdata[0]}</b><br>Budget: %{customdata[1]}<br>Percent: %{percent}')
    # Hide the legend so the pie chart displays without the legend beside it
    pie_fig.update_layout(**common_layout, title_x=0.5, showlegend=False)

    # SCATTER
    scatter_sample = filtered.sample(min(5000, len(filtered)))
    scatter_fig = px.scatter(scatter_sample,
                             x='Training_Hours', y='Impact_Score', color='Sector_short',
                             title="Impact vs Training Hours",
                             hover_data=['Project_Name_short','County_short','Training_label','Project_Budget_label'])
    scatter_fig.update_traces(marker=dict(size=5, opacity=0.6),
                              hovertemplate='<b>%{customdata[0]}</b><br>%{customdata[1]}<br>Training: %{customdata[2]}<br>Budget: %{customdata[3]}')
    scatter_fig.update_layout(**common_layout, title_x=0.5, showlegend=False)

    # TREEMAP for beneficiaries by county (clear, heat-like visualization)
    county_map = filtered.groupby("County")["Beneficiary_ID"].nunique().reset_index()
    county_map['County_short'] = county_map['County'].apply(first_word)
    county_map['Beneficiaries_label'] = county_map['Beneficiary_ID'].apply(number_short)
    map_fig = px.treemap(county_map, path=['County_short'], values='Beneficiary_ID',
                         color='Beneficiary_ID', color_continuous_scale='YlOrRd',
                         title='Beneficiaries by County (treemap)')
    # Use custom hover to show full county and formatted beneficiaries
    map_fig.update_traces(hovertemplate='<b>%{label}</b><br>Beneficiaries: %{value}')
    map_fig.update_layout(**common_layout, title_x=0.5)

    # HIST
    hist_fig = px.histogram(filtered, x="Age", nbins=20, title="Beneficiary Age Distribution",
                            color_discrete_sequence=[SECONDARY])
    hist_fig.update_layout(**common_layout, title_x=0.5)

    return kpi_cards, bar_fig, line_fig, pie_fig, scatter_fig, map_fig, hist_fig

# ---------- RUN ----------
# Duplicate/old report route removed; new /report and /download handlers are defined earlier in the file.


# ---------- RUN ----------
if __name__ == "__main__":
    # Print startup info to help with quick verification when running
    try:
        print(f"DATA_PATH: {DATA_PATH}")
        print(f"Rows loaded: {len(df):,}")
    except Exception as e:
        print("Startup info unavailable:", e)

    # Determine host/port from environment for platforms like Render/Heroku
    # Render and similar platforms expect the app to bind to 0.0.0.0 and use
    # the PORT environment variable provided by the platform.
    port = int(os.environ.get("PORT", 8050))
    host = os.environ.get("HOST", "0.0.0.0")

    print(f"Starting server on {host}:{port}")

    # By default we don't enable the reloader here to avoid duplicate processes/logging
    # when the app is run by a production WSGI server (gunicorn). For local development
    # you can enable the reloader by setting the FLASK_DEBUG (or DEBUG) env var to
    # 1/true. When debug is enabled we pass use_reloader=True so file changes will
    # restart the process automatically.
    debug_env = os.environ.get("FLASK_DEBUG", os.environ.get("DEBUG", "0"))
    debug = str(debug_env).lower() in ("1", "true", "yes")

    if debug:
        print("Running in development mode: debug/reloader enabled")

    # The 'use_reloader' argument makes the server restart when files change.
    # Keep this off by default for production (gunicorn/Procfile) but allow
    # toggling via environment for local development.
    app.run(debug=debug, host=host, port=port, use_reloader=debug)


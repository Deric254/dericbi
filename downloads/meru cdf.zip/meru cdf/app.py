import json
import os
import pandas as pd
import dash
from dash import dcc, html, Input, Output, State
import plotly.express as px
import random
import base64
import io
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend

# Helper function to format numbers with suffixes
def format_number(num):
    if pd.isna(num):
        return num
    num = float(num)
    if abs(num) >= 1e12:
        return f"{num/1e12:.2f}T"
    elif abs(num) >= 1e9:
        return f"{num/1e9:.2f}B"
    elif abs(num) >= 1e6:
        return f"{num/1e6:.2f}M"
    elif abs(num) >= 1e3:
        return f"{num/1e3:.2f}K"
    else:
        return f"{num:.2f}"

# Load data
with open("data/meru_projects.json") as f:
    data = json.load(f)

# Try to load constituency GeoJSON polygons for precise point-in-polygon checks
geojson_polygons = {}
geojson_name_key = None
geojson_path = os.path.join(os.path.dirname(__file__), 'data', 'meru_constituencies.geojson')
try:
    if os.path.exists(geojson_path):
        with open(geojson_path, 'r', encoding='utf-8') as gf:
            gj = json.load(gf)
        # lazy import shapely
        try:
            from shapely.geometry import shape, Point
            for feat in gj.get('features', []) or []:
                props = feat.get('properties', {})
                # find a sensible name property
                if geojson_name_key is None:
                    for k in props.keys():
                        if k.lower() in ('name', 'constituency', 'const', 'county', 'ward'):
                            geojson_name_key = k
                            break
                if geojson_name_key and props.get(geojson_name_key):
                    name = str(props.get(geojson_name_key)).strip()
                    try:
                        poly = shape(feat.get('geometry'))
                        geojson_polygons[name.lower()] = poly
                    except Exception:
                        # skip invalid geometries
                        continue
        except Exception:
            # shapely not available or load failed; leave geojson_polygons empty
            geojson_polygons = {}
except Exception:
    geojson_polygons = {}

# List of constituencies
constituencies = list(data.keys())

# Initialize Dash app
app = dash.Dash(__name__, title="Meru Constituency Dashboard")

# Helper to pick an asset path if the preferred filename exists, else fallback
def asset_path(preferred, fallback):
    assets_dir = os.path.join(os.path.dirname(__file__), 'assets')
    preferred_path = os.path.join(assets_dir, preferred)
    fallback_path = os.path.join(assets_dir, fallback)
    if os.path.exists(preferred_path):
        return f'/assets/{preferred}'
    if os.path.exists(fallback_path):
        return f'/assets/{fallback}'
    # last resort: return preferred so Dash will show alt text instead of 404
    return f'/assets/{preferred}'

# App Layout
app.layout = html.Div(className='dash-container', children=[
    # Header: centered title with small logos left and right (uses files in assets/)
    html.Div(className='app-header card', children=[
    # left logo (will show if the file exists in assets/)
    html.A(html.Img(src=asset_path('logo.png', 'deric_logo.svg'), className='header-logo', alt='Left logo'), href="https://dericbi.netlify.app/my-projects", target="_blank"),

        # centered title
        html.H1("Meru County NG-CDF Project Dashboard"),

    # right user image/logo (will show if the file exists in assets/)
    html.A(html.Img(src=asset_path('deric.png', 'user_image.svg'), className='header-user-img', alt='Right logo'), href="https://dericmarangu-portfolio.netlify.app", target="_blank")
    ]),

    html.Div(className='controls', children=[
        html.Div(className='card', children=[
            html.Label("Select Constituency:"),
            dcc.Dropdown(
                id='constituency-dropdown',
                options=[{'label': c, 'value': c} for c in constituencies],
                # default to South Imenti if available
                value='South Imenti' if 'South Imenti' in constituencies else (constituencies[0] if constituencies else None)
            )
        ], style={'minWidth':'200px'}),

        html.Div(className='card', children=[
            html.Label("Filter by Sector:"),
            dcc.Dropdown(id='sector-dropdown', multi=True)
        ], style={'minWidth':'300px'}),

        # Status slicer: placed on the same controls row
        # Status slicer as a checklist for quicker multi-select
        html.Div(className='card', children=[
            html.Label("Filter by Status:"),
            dcc.Checklist(id='status-checklist', className='status-checklist')
        ], style={'minWidth':'200px'}),
        
        # PDF Export Button
        html.Div(className='card', children=[
            html.Label("Export Report:"),
            html.Button('Download PDF Report', id='export-pdf', n_clicks=0, 
                       style={'margin':'8px', 'backgroundColor':'#006837', 'color':'white', 'border':'none', 'padding':'8px 16px', 'borderRadius':'4px'}),
            dcc.Download(id='download-pdf')
        ], style={'minWidth':'200px'})
    ]),

    # KPI Section
    html.Div(id='kpi-section', className='kpi-row'),

    html.Div(className='charts', children=[
        html.Div(className='top-charts', children=[
            html.Div(className='card', children=[dcc.Graph(id='budget-bar')]),
            html.Div(className='card', children=[dcc.Graph(id='completion-pie')])
        ]),

        # Full-width map row so the map has enough space
        html.Div(className='map-row', children=[
            html.Div(className='card', children=[dcc.Graph(id='project-map')])
        ])
    ]),

    # Collapsible Project Details Section - COLLAPSED BY DEFAULT
    html.Div(className='collapsible-section', children=[
        html.Button(
            'Project Details ▼', 
            id='project-details-toggle', 
            className='collapsible-header'
        ),
        html.Div(id='project-table-container', className='collapsible-content', style={'display': 'none'})
    ]),
    
    html.Div(className='card', children=[
        html.Button('Export flagged projects (CSV)', id='export-flagged', n_clicks=0, style={'margin':'8px'}),
        dcc.Download(id='download-flagged')
    ], style={'textAlign':'center'}),

    html.Div(className='card footer-links', children=[
        html.Div(className='footer-inner', children=[
            html.Div(className='footer-left', children=[
                # user's image (replace file in assets/ with your real photo named deric.png)
                html.A(html.Img(src=asset_path('deric.png', 'user_image.svg'), className='footer-user-img', alt='Your photo'), href="https://dericmarangu-portfolio.netlify.app", target="_blank"),
            ]),

            html.Div(className='footer-center', children=[
                html.P("Clarity of mind and ideas is my call. Let's collaborate!", className='muted'),
                html.Div([
                    html.A("See my portfolio", href="https://dericbi.netlify.app/my-projects", target="_blank"),
                    html.Br(),
                    html.A("Email Me", href="mailto:dericmarangu@gmail.com"),
                    html.Br(),
                    html.A("Hire me", href="https://wa.me/254791360805")
                ])
            ]),

            html.Div(className='footer-right', children=[
                html.A(html.Img(src=asset_path('logo.png', 'deric_logo.svg'), className='footer-logo', alt='Logo'), href="https://dericbi.netlify.app/my-projects", target="_blank"),
                html.Div('we analyze you decie', className='tagline')
            ])
        ])
    ], style={'textAlign':'center', 'marginTop':'18px'})
])

# Callbacks
@app.callback(
    Output('sector-dropdown', 'options'),
    Output('sector-dropdown', 'value'),
    Output('status-checklist', 'options'),
    Output('status-checklist', 'value'),
    Input('constituency-dropdown', 'value')
)
def update_filters(selected_const):
    # Populate sector dropdown and status checklist based on selected constituency
    df = pd.DataFrame(data[selected_const])
    # Ensure a status column exists and normalize missing values to 'Unknown'
    if 'status' not in df.columns:
        df['status'] = pd.NA
    df['status'] = df['status'].fillna('Unknown')
    sectors = df['sector'].unique()
    sector_options = [{'label': s, 'value': s} for s in sectors]

    statuses = df['status'].unique()
    status_options = [{'label': s, 'value': s} for s in statuses]

    # default select all available sectors and statuses
    return sector_options, sectors.tolist(), status_options, statuses.tolist()

@app.callback(
    Output('budget-bar', 'figure'),
    Output('completion-pie', 'figure'),
    Output('project-map', 'figure'),
    Output('project-table-container', 'children'),
    Output('kpi-section', 'children'),
    Input('constituency-dropdown', 'value'),
    Input('sector-dropdown', 'value'),
    Input('status-checklist', 'value')
)
def update_dashboard(selected_const, selected_sectors, selected_statuses):
    df = pd.DataFrame(data[selected_const])
    # Ensure a status column exists and normalize missing values to 'Unknown'
    if 'status' not in df.columns:
        df['status'] = pd.NA
    df['status'] = df['status'].fillna('Unknown')
    
    # Ensure numeric columns are properly typed for accurate calculations
    df['completion'] = pd.to_numeric(df['completion'], errors='coerce').fillna(0).clip(0, 100)
    df['budget'] = pd.to_numeric(df['budget'], errors='coerce').fillna(0)
    
    if selected_sectors:
        df = df[df['sector'].isin(selected_sectors)]
    if selected_statuses:
        df = df[df['status'].isin(selected_statuses)]
    
    # Compute KPIs with validated data
    total_budget = df['budget'].sum()
    total_projects = len(df)
    avg_completion = df['completion'].mean() if total_projects > 0 else 0
    completed_projects = len(df[(df['status'].str.lower() == 'completed') | (df['completion'] >= 100)]) if 'status' in df.columns else 0
    
    kpi_cards = html.Div(className='kpi-container', children=[
        html.Div(className='kpi-card', children=[
            html.H3("Total Budget"),
            html.P(format_number(total_budget), className='kpi-value')
        ]),
        html.Div(className='kpi-card', children=[
            html.H3("Total Projects"),
            html.P(str(total_projects), className='kpi-value')
        ]),
        html.Div(className='kpi-card', children=[
            html.H3("Avg Completion"),
            html.P(f"{avg_completion:.1f}%", className='kpi-value')
        ]),
        html.Div(className='kpi-card', children=[
            html.H3("Completed Projects"),
            html.P(str(completed_projects), className='kpi-value')
        ])
    ])
    
    # Budget per sector: color bars by sector using a Meru palette
    budget_df = df.groupby('sector', as_index=False)['budget'].sum()
    budget_df['formatted_budget'] = budget_df['budget'].apply(format_number)
    meru_palette = ['#006837', '#f2c94c', '#b22222', '#06b6d4', '#2563eb', '#8b5cf6', '#f97316']
    budget_fig = px.bar(budget_df, x='sector', y='budget', color='sector',
                        color_discrete_sequence=meru_palette, title='Budget Allocated per Sector', text='formatted_budget')
    budget_fig.update_traces(textposition='auto', textfont_color='white', textfont_size=10,
                             hovertemplate='Sector: %{x}<br>Budget: %{text}<extra></extra>')
    budget_fig.update_yaxes(tickformat='.2s')
    budget_fig.update_layout(
        showlegend=False,
        margin=dict(l=20, r=20, t=40, b=20),  # Minimal margins to utilize full container
        autosize=True  # Allow chart to resize to container
    )

    # Completion pie: color-code by status
    # Map common status labels to Meru palette
    color_map = {}
    for s in df['status'].unique():
        key = str(s).lower()
        if 'complete' in key:
            color_map[s] = '#006837'  # meru green
        elif 'ongo' in key or 'progress' in key:
            color_map[s] = '#f2c94c'  # meru gold
        elif 'plan' in key:
            color_map[s] = '#b22222'  # meru red
        else:
            # fallback: use plotly defaults (no mapping)
            color_map[s] = None

    # remove None entries from mapping so plotly uses default palette for them
    color_map = {k: v for k, v in color_map.items() if v}

    # Use meru_palette for pie if mapping missing for some statuses
    pie_colors = color_map if color_map else None
    pie_fig = px.pie(df, names='status', values='completion', title='Project Completion Status',
                     color_discrete_map=pie_colors, color_discrete_sequence=meru_palette if not pie_colors else None)
    pie_fig.update_traces(textinfo='value+percent', texttemplate='%{value:.2f}<br>%{percent:.2%}')

    # Map visual: use lat/lon if provided in data, otherwise assign approximate constituency centroids
    # Approximate centroids for Meru County constituencies (lat, lon)
    constituency_centroids = {
        'Central Imenti': (0.050, 37.650),
        'South Imenti': (0.010, 37.630),
        'North Imenti': (0.120, 37.660),
        'Buuri': (0.080, 37.700),
        'Igembe Central': (0.450, 37.900),
        'Igembe North': (0.600, 37.950),
        'Igembe South': (0.350, 37.850),
        'Tigania East': (0.200, 37.700),
        'Tigania West': (0.180, 37.620)
    }

    # find lat/lon columns if present
    lat_col = next((c for c in df.columns if c.lower() in ('lat', 'latitude')), None)
    lon_col = next((c for c in df.columns if c.lower() in ('lon', 'longitude', 'long')), None)

    map_df = df.copy()
    # Populate lat/lon only if explicit coordinates are provided. Do NOT auto-jitter missing
    # coordinates — plotting only explicit, in-bounds coordinates improves accuracy.
    if lat_col and lon_col:
        map_df['lat'] = pd.to_numeric(map_df[lat_col], errors='coerce')
        map_df['lon'] = pd.to_numeric(map_df[lon_col], errors='coerce')
    else:
        # no lat/lon columns present — leave lat/lon as NaN so we can flag them for correction
        map_df['lat'] = pd.NA
        map_df['lon'] = pd.NA

    # Define approximate per-constituency bounding boxes (lat_min, lat_max, lon_min, lon_max)
    # based on centroids with a reasonable radius — replace with precise GeoJSON for best accuracy.
    constituency_bboxes = {}
    bbox_radius = 0.2  # ~22km - adjust as needed
    for cname, cent in constituency_centroids.items():
        lat_c, lon_c = cent
        constituency_bboxes[cname] = (lat_c - bbox_radius, lat_c + bbox_radius, lon_c - bbox_radius, lon_c + bbox_radius)

    # For the selected constituency, compute which projects have explicit coordinates and
    # which of those lie within the constituency bbox. We'll only plot the in-bounds ones.
    bbox = constituency_bboxes.get(selected_const, (0.0465 - bbox_radius, 0.0465 + bbox_radius, 37.6493 - bbox_radius, 37.6493 + bbox_radius))
    lat_min, lat_max, lon_min, lon_max = bbox
    map_df['has_coords'] = map_df['lat'].notnull() & map_df['lon'].notnull()
    # numeric comparison (handles pandas NA)
    map_df['in_bounds'] = False
    mask_coords = map_df['has_coords']
    if mask_coords.any():
        mask_in = (map_df.loc[mask_coords, 'lat'].astype(float) >= lat_min) & (map_df.loc[mask_coords, 'lat'].astype(float) <= lat_max) & \
                  (map_df.loc[mask_coords, 'lon'].astype(float) >= lon_min) & (map_df.loc[mask_coords, 'lon'].astype(float) <= lon_max)
        map_df.loc[mask_coords, 'in_bounds'] = mask_in

    # Use the same color map for the map (status -> color) when available
    map_color_map = color_map if color_map else None

    # Prepare GeoJSON mask (defined once so available in both non-empty and empty cases)
    meru_lon_min, meru_lat_min = 37.0, -0.5
    meru_lon_max, meru_lat_max = 38.5, 0.5
    geojson_mask = {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": [
                [
                    [-180.0, -90.0], [180.0, -90.0], [180.0, 90.0], [-180.0, 90.0], [-180.0, -90.0]
                ],
                [
                    [meru_lon_min, meru_lat_min], [meru_lon_max, meru_lat_min], [meru_lon_max, meru_lat_max], [meru_lon_min, meru_lat_max], [meru_lon_min, meru_lat_min]
                ]
            ]
        }
    }

    # Split projects by coordinate validity and whether they fall in the constituency bbox
    valid_df = map_df[map_df['in_bounds']].copy()
    missing_coords_df = map_df[~map_df['has_coords']].copy()
    out_of_bounds_df = map_df[map_df['has_coords'] & ~map_df['in_bounds']].copy()

    # Prepare a Meru county outline polygon from the bbox so the county boundary is visible
    meru_outline = {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": [[
                [meru_lon_min, meru_lat_min], [meru_lon_max, meru_lat_min], [meru_lon_max, meru_lat_max], [meru_lon_min, meru_lat_max], [meru_lon_min, meru_lat_min]
            ]]
        }
    }

    if len(valid_df):
        # Format budget and completion for hover
        valid_df = valid_df.copy()
        valid_df['budget'] = valid_df['budget'].astype(float)
        valid_df['completion'] = valid_df['completion'].astype(float)
        valid_df['budget_formatted'] = valid_df['budget'].apply(format_number)
        valid_df['completion_formatted'] = valid_df['completion'].apply(format_number)
        map_fig = px.scatter_mapbox(valid_df, lat='lat', lon='lon', hover_name='name',
                                    hover_data=['sector', 'status', 'completion_formatted', 'budget_formatted'],
                                    color='status', color_discrete_map=map_color_map,
                                    zoom=10, height=450)
        map_fig.update_traces(marker={'size':12, 'opacity':0.85})

        # center and zoom to valid data extent for better visibility
        center_lat = valid_df['lat'].mean()
        center_lon = valid_df['lon'].mean()
        lat_span = valid_df['lat'].max() - valid_df['lat'].min() if len(valid_df) > 1 else 0
        lon_span = valid_df['lon'].max() - valid_df['lon'].min() if len(valid_df) > 1 else 0
        max_span = max(lat_span, lon_span)
        if max_span > 1:
            zoom = 8
        elif max_span > 0.5:
            zoom = 9
        elif max_span > 0.2:
            zoom = 10
        elif max_span > 0.05:
            zoom = 11
        else:
            zoom = 12
        zoom = min(zoom, 11)

        map_fig.update_layout(
            mapbox_style='open-street-map',
            margin={'r':0,'t':30,'l':0,'b':0},
            title='Project Locations in ' + str(selected_const),
            mapbox={
                'center': {'lat': center_lat, 'lon': center_lon},
                'zoom': zoom,
                'layers': [
                    {
                        'sourcetype': 'geojson',
                        'source': geojson_mask,
                        'type': 'fill',
                        'color': 'rgba(2,6,23,0.55)',
                        'below': 'traces'
                    },
                    {
                        'sourcetype': 'geojson',
                        'source': meru_outline,
                        'type': 'line',
                        'color': '#006837',
                        'line': {'width': 3}
                    }
                ]
            }
        )
    else:
        # empty map or no valid coordinates: center on constituency centroid
        center = constituency_centroids.get(selected_const, (0.0465, 37.6493))
        map_fig = px.scatter_mapbox(lat=[center[0]], lon=[center[1]], zoom=10, height=400)
        map_fig.update_layout(mapbox_style='open-street-map', margin={'r':0,'t':30,'l':0,'b':0}, title='Project Locations (none)',
                              mapbox={'center': {'lat': center[0], 'lon': center[1]}, 'zoom': 10, 'layers': [{
                                  'sourcetype': 'geojson',
                                  'source': geojson_mask,
                                  'type': 'fill',
                                  'color': 'rgba(2,6,23,0.55)',
                                  'below': 'traces'
                              }, {
                                  'sourcetype': 'geojson',
                                  'source': meru_outline,
                                  'type': 'line',
                                  'color': '#006837',
                                  'line': {'width': 3}
                              }]})

    # Table
    # Table with color-coded status badges
    header = html.Tr([html.Th(col) for col in df.columns])
    rows = []
    for i in range(len(df)):
        cells = []
        for col in df.columns:
            val = df.iloc[i][col]
            if str(col).lower() == 'status':
                cls = 'status-badge status-' + str(val).lower().replace(' ', '-')
                cells.append(html.Td(html.Span(str(val), className=cls)))
            else:
                # Format numeric values with suffixes
                if isinstance(val, (int, float)) and not pd.isna(val):
                    formatted_val = format_number(val)
                else:
                    formatted_val = str(val)
                cells.append(html.Td(formatted_val))
        rows.append(html.Tr(cells))

    table = html.Table([header] + rows, style={'margin':'auto', 'width':'80%', 'border':'1px solid black', 'borderCollapse':'collapse'})

    # Build diagnostics for coordinates so the user can correct bad or missing data
    diagnostics = []
    if len(missing_coords_df):
        diagnostics.append(html.Div([
            html.H4("Projects missing coordinates (please add 'latitude' and 'longitude')", style={'color':'#b22222'}),
            html.Ul([html.Li(str(r['name'])) for _, r in missing_coords_df.iterrows()])
        ], style={'margin':'12px'}))

    if len(out_of_bounds_df):
        diagnostics.append(html.Div([
            html.H4("Projects with coordinates outside the selected constituency bbox", style={'color':'#f2c94c'}),
            html.Table([
                html.Thead(html.Tr([html.Th('Project'), html.Th('lat'), html.Th('lon'), html.Th('Status')])),
                html.Tbody([
                    html.Tr([html.Td(r['name']), html.Td(str(r['lat'])), html.Td(str(r['lon'])), html.Td(r.get('status', ''))])
                    for _, r in out_of_bounds_df.iterrows()
                ])
            ], style={'margin':'8px'})
        ], style={'margin':'12px'}))

    table_container_children = [table]
    if diagnostics:
        table_container_children += diagnostics

    table_container = html.Div(table_container_children)

    return budget_fig, pie_fig, map_fig, table_container, kpi_cards


@app.callback(
    Output('download-flagged', 'data'),
    Input('export-flagged', 'n_clicks'),
    State('constituency-dropdown', 'value'),
    State('sector-dropdown', 'value'),
    State('status-checklist', 'value')
)
def export_flagged(n_clicks, selected_const, selected_sectors, selected_statuses):
    # When the user clicks the export button, recompute flagged projects and return a CSV
    if not n_clicks:
        return dash.no_update

    df = pd.DataFrame(data[selected_const])
    if 'status' not in df.columns:
        df['status'] = pd.NA
    df['status'] = df['status'].fillna('Unknown')
    if selected_sectors:
        df = df[df['sector'].isin(selected_sectors)]
    if selected_statuses:
        df = df[df['status'].isin(selected_statuses)]

    lat_col = next((c for c in df.columns if c.lower() in ('lat', 'latitude')), None)
    lon_col = next((c for c in df.columns if c.lower() in ('lon', 'longitude', 'long')), None)
    map_df = df.copy()
    if lat_col and lon_col:
        map_df['lat'] = pd.to_numeric(map_df[lat_col], errors='coerce')
        map_df['lon'] = pd.to_numeric(map_df[lon_col], errors='coerce')
    else:
        map_df['lat'] = pd.NA
        map_df['lon'] = pd.NA

    map_df['has_coords'] = map_df['lat'].notnull() & map_df['lon'].notnull()
    # Determine in_bounds using GeoJSON if available, otherwise bbox fallback
    map_df['in_bounds'] = False
    if geojson_polygons and selected_const and selected_const.lower() in geojson_polygons:
        poly = geojson_polygons[selected_const.lower()]
        from shapely.geometry import Point
        for idx, row in map_df.iterrows():
            if row['has_coords']:
                try:
                    pt = Point(float(row['lon']), float(row['lat']))
                    map_df.at[idx, 'in_bounds'] = poly.contains(pt) or poly.touches(pt)
                except Exception:
                    map_df.at[idx, 'in_bounds'] = False
    else:
        # bbox fallback (same as update_dashboard)
        centroid = (0.0465, 37.6493)
        bbox_radius = 0.2
        lat_min, lat_max = centroid[0] - bbox_radius, centroid[0] + bbox_radius
        lon_min, lon_max = centroid[1] - bbox_radius, centroid[1] + bbox_radius
        mask_coords = map_df['has_coords']
        if mask_coords.any():
            mask_in = (map_df.loc[mask_coords, 'lat'].astype(float) >= lat_min) & (map_df.loc[mask_coords, 'lat'].astype(float) <= lat_max) & \
                      (map_df.loc[mask_coords, 'lon'].astype(float) >= lon_min) & (map_df.loc[mask_coords, 'lon'].astype(float) <= lon_max)
            map_df.loc[mask_coords, 'in_bounds'] = mask_in

    missing_coords_df = map_df[~map_df['has_coords']]
    out_of_bounds_df = map_df[map_df['has_coords'] & ~map_df['in_bounds']]

    flagged = pd.concat([missing_coords_df, out_of_bounds_df], ignore_index=True)
    if flagged.empty:
        # return an empty CSV with headers
        flagged = pd.DataFrame(columns=list(map_df.columns))

    return dcc.send_data_frame(flagged.to_csv, "flagged_projects.csv", index=False)

# Callback for collapsible Project Details section
@app.callback(
    Output('project-table-container', 'style'),
    Output('project-details-toggle', 'children'),
    Input('project-details-toggle', 'n_clicks'),
    State('project-table-container', 'style'),
    prevent_initial_call=True
)
def toggle_project_details(n_clicks, current_style):
    if n_clicks is None:
        n_clicks = 0
        
    if n_clicks % 2 == 1:  # Odd clicks = expanded
        return {'display': 'block'}, 'Project Details ▲'
    else:  # Even clicks = collapsed
        return {'display': 'none'}, 'Project Details ▼'

# PDF Export Callback
@app.callback(
    Output('download-pdf', 'data'),
    Input('export-pdf', 'n_clicks'),
    State('constituency-dropdown', 'value'),
    State('sector-dropdown', 'value'),
    State('status-checklist', 'value'),
    prevent_initial_call=True
)
def generate_pdf_report(n_clicks, selected_const, selected_sectors, selected_statuses):
    if not n_clicks or not selected_const:
        return dash.no_update
    
    try:
        # Create a buffer for the PDF
        buffer = io.BytesIO()
        
        # Create the PDF document
        doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=0.5*inch)
        styles = getSampleStyleSheet()
    
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            textColor=colors.HexColor('#006837'),
            alignment=1  # Center aligned
        )
        
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            textColor=colors.HexColor('#006837')
        )
        
        # Story to hold all elements
        story = []
        
        # Header with logo and title
        try:
            # Try to load logo
            logo_path = os.path.join(os.path.dirname(__file__), 'assets', 'logo.png')
            if os.path.exists(logo_path):
                logo = Image(logo_path, width=1.5*inch, height=1*inch)
                story.append(logo)
        except Exception as logo_error:
            print(f"Logo loading error: {logo_error}")
            pass
        
        # Title
        title = Paragraph(f"Meru County NG-CDF Project Report - {selected_const}", title_style)
        story.append(title)
        story.append(Spacer(1, 0.2*inch))
        
        # Report metadata
        metadata_style = ParagraphStyle(
            'Metadata',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.gray
        )
        
        from datetime import datetime
        report_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        metadata = Paragraph(f"Report generated on: {report_date}", metadata_style)
        story.append(metadata)
        
        if selected_sectors:
            sectors_text = ", ".join(selected_sectors)
            sectors_para = Paragraph(f"Filtered sectors: {sectors_text}", metadata_style)
            story.append(sectors_para)
        
        if selected_statuses:
            status_text = ", ".join(selected_statuses)
            status_para = Paragraph(f"Filtered statuses: {status_text}", metadata_style)
            story.append(status_para)
        
        story.append(Spacer(1, 0.3*inch))
        
        # KPI Summary
        kpi_heading = Paragraph("Executive Summary", heading_style)
        story.append(kpi_heading)
        
        # Get the data for KPIs
        df = pd.DataFrame(data[selected_const])
        if 'status' not in df.columns:
            df['status'] = pd.NA
        df['status'] = df['status'].fillna('Unknown')
        if selected_sectors:
            df = df[df['sector'].isin(selected_sectors)]
        if selected_statuses:
            df = df[df['status'].isin(selected_statuses)]
        
        # Ensure numeric columns
        df['completion'] = pd.to_numeric(df['completion'], errors='coerce').fillna(0).clip(0, 100)
        df['budget'] = pd.to_numeric(df['budget'], errors='coerce').fillna(0)
        
        # Compute KPIs
        total_budget = df['budget'].sum()
        total_projects = len(df)
        avg_completion = df['completion'].mean() if total_projects > 0 else 0
        completed_projects = len(df[(df['status'].str.lower() == 'completed') | (df['completion'] >= 100)]) if 'status' in df.columns else 0
        
        # KPI table
        kpi_data = [
            ['Metric', 'Value'],
            ['Total Budget', format_number(total_budget)],
            ['Total Projects', str(total_projects)],
            ['Average Completion', f"{avg_completion:.1f}%"],
            ['Completed Projects', str(completed_projects)]
        ]
        
        kpi_table = Table(kpi_data, colWidths=[3*inch, 2*inch])
        kpi_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#006837')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        story.append(kpi_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Charts Section
        charts_heading = Paragraph("Visual Analytics", heading_style)
        story.append(charts_heading)
        story.append(Spacer(1, 0.2*inch))
        
        try:
            # Create charts with clean layout
            fig = plt.figure(figsize=(15, 6), facecolor='white')
            
            # Create subplots with proper spacing
            ax1 = fig.add_axes([0.05, 0.15, 0.50, 0.75])  # Bar chart - increased width
            ax2 = fig.add_axes([0.58, 0.15, 0.37, 0.75])  # Pie chart - adjusted position and width
            
            # Define colors
            colors_pie = ['#006837', '#f2c94c', '#b22222', '#06b6d4', '#2563eb']
            
            # Budget by Sector Bar Chart
            budget_df = df.groupby('sector', as_index=False)['budget'].sum()
            bars = ax1.bar(budget_df['sector'], budget_df['budget'], color='#006837', width=0.8)
            ax1.set_title('Budget Allocation by Sector', fontsize=14, fontweight='bold', pad=10)
            ax1.set_ylabel('Budget (KES)', fontsize=11)
            ax1.tick_params(axis='x', rotation=45, labelsize=9)
            ax1.tick_params(axis='y', labelsize=9)
            ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: format_number(x)))
            ax1.grid(axis='y', alpha=0.3)
            
            # Add value labels on bars
            for bar, value in zip(bars, budget_df['budget']):
                height = bar.get_height()
                ax1.text(bar.get_x() + bar.get_width()/2., height + max(budget_df['budget'])*0.01,
                        format_number(value), ha='center', va='bottom', fontsize=8, fontweight='bold')
            
            # Project Status Distribution Pie Chart
            status_counts = df['status'].value_counts()
            wedges, texts, autotexts = ax2.pie(status_counts.values, labels=status_counts.index, 
                                              autopct=lambda pct: f'{pct:.1f}%\n({int(pct/100.*sum(status_counts.values))})', 
                                              colors=colors_pie[:len(status_counts)], 
                                              startangle=90, pctdistance=0.75, labeldistance=1.05,
                                              wedgeprops={'edgecolor': 'white', 'linewidth': 2})
            ax2.set_title('Project Distribution by Status', fontsize=14, fontweight='bold', pad=10)
            ax2.axis('equal')
            
            # Improve text sizes
            plt.setp(autotexts, size=9, weight="bold")
            plt.setp(texts, size=10)
            
            # Save chart
            chart_buffer = io.BytesIO()
            fig.savefig(chart_buffer, format='png', dpi=150, bbox_inches='tight', pad_inches=0.1)
            chart_buffer.seek(0)
            
            # Add chart to PDF
            chart_img = Image(chart_buffer, width=7.5*inch, height=4*inch)
            story.append(chart_img)
            
            # Add chart descriptions with actual data
            desc_style = ParagraphStyle(
                'Description',
                parent=styles['Normal'],
                fontSize=10,
                spaceAfter=6,
                textColor=colors.gray
            )
            
            total_budget_formatted = format_number(total_budget)
            top_sector = budget_df.loc[budget_df['budget'].idxmax(), 'sector'] if not budget_df.empty else 'N/A'
            top_budget = format_number(budget_df['budget'].max()) if not budget_df.empty else '0'
            
            bar_desc = Paragraph(f"• <b>Budget Allocation by Sector:</b> Total budget: {total_budget_formatted} KES. Top sector: {top_sector} ({top_budget} KES). This bar chart shows budget distribution across sectors.", desc_style)
            story.append(bar_desc)
            
            total_projects_count = len(df)
            status_breakdown = ", ".join([f"{status}: {count}" for status, count in status_counts.items()])
            
            pie_desc = Paragraph(f"• <b>Project Distribution by Status:</b> Total projects: {total_projects_count}. Breakdown: {status_breakdown}. This pie chart shows project counts by completion status.", desc_style)
            story.append(pie_desc)
            
            story.append(Spacer(1, 0.3*inch))
            
            plt.close(fig)
        
        except Exception as e:
            print(f"Chart generation error: {e}")
            error_note = Paragraph(f"Note: Visual charts could not be generated due to: {str(e)}", 
                                  ParagraphStyle('Error', parent=styles['Normal'], textColor=colors.red))
            story.append(error_note)
            story.append(Spacer(1, 0.2*inch))
    
        # Project Details
        details_heading = Paragraph("Project Details", heading_style)
        story.append(details_heading)
        
        # Prepare table data - limit columns for better readability
        important_columns = ['name', 'sector', 'status', 'completion', 'budget']
        available_columns = [col for col in important_columns if col in df.columns]
        
        table_data = [available_columns]
        for _, row in df.iterrows():
            table_row = []
            for col in available_columns:
                val = row[col]
                if isinstance(val, (int, float)) and not pd.isna(val):
                    if col == 'budget':
                        formatted_val = format_number(val)
                    elif col == 'completion':
                        formatted_val = f"{val:.1f}%"
                    else:
                        formatted_val = str(val)
                else:
                    formatted_val = str(val)
                table_row.append(formatted_val)
            table_data.append(table_row)
        
        # Create table with adjusted column widths
        col_widths = [2.5*inch, 1.5*inch, 1.5*inch, 1*inch, 1.5*inch]
        project_table = Table(table_data, colWidths=col_widths[:len(available_columns)], repeatRows=1)
        project_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#006837')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
        ]))
        story.append(project_table)
        
        # Footer with contact information
        story.append(Spacer(1, 0.3*inch))
        
        # Try to add profile image (use PNG if available)
        try:
            profile_img_path = os.path.join(os.path.dirname(__file__), 'assets', 'deric_logo.png')
            if not os.path.exists(profile_img_path):
                # Try SVG if PNG not found
                profile_img_path = os.path.join(os.path.dirname(__file__), 'assets', 'deric_logo.svg')
            if os.path.exists(profile_img_path) and profile_img_path.endswith('.png'):
                profile_img = Image(profile_img_path, width=0.8*inch, height=0.8*inch)
                story.append(profile_img)
        except Exception as img_error:
            print(f"Profile image loading error: {img_error}")
            pass
        footer_style = ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontSize=9,
            textColor=colors.gray,
            alignment=1,
            spaceAfter=4
        )
        
        contact_info = Paragraph("Report Generated by: Deric Marangu<br/>Phone: +254 791 360 805 | Email: dericmarangu@gmail.com<br/>Meru County NG-CDF Dashboard - Professional Report", footer_style)
        story.append(contact_info)
        
        # Build PDF
        doc.build(story)
        
        # Return the PDF
        buffer.seek(0)
        filename = f"meru_ngcdf_report_{selected_const.replace(' ', '_') if selected_const else 'unknown'}.pdf"
        return dcc.send_bytes(buffer.read(), filename)
        
    except Exception as e:
        print(f"PDF generation error: {e}")
        # Return no update if error
        return dash.no_update
if __name__ == '__main__':
    # Dash 2.9+ replaced `run_server` with `run`
    # Bind to 0.0.0.0 and use the PORT env var (required by many PaaS providers like Render)
    # For production deployments, prefer a WSGI server such as gunicorn:
    #   web: gunicorn app:app.server --bind 0.0.0.0:$PORT
    port = int(os.environ.get('PORT', 8050))
    host = '0.0.0.0'
    app.run(host=host, port=port, debug=False, use_reloader=False)
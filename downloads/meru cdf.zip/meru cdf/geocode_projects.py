#!/usr/bin/env python3
"""
Geocode projects in data/meru_projects.json using Nominatim (OpenStreetMap).

Usage:
  python geocode_projects.py [--overwrite] [--delay SECONDS]

This script will read data/meru_projects.json, attempt to geocode each project using
its name and constituency, and write latitude/longitude into the JSON. By default the
script writes a new file data/meru_projects.geocoded.json and a CSV report of failures.

Notes:
- Respects a per-request delay (default 1s) to avoid hitting Nominatim rate limits.
- You must run this locally (the script performs network calls). Do not run bulk
  rapid queries against the public Nominatim service; see https://operations.osmfoundation.org/policies/nominatim/.
"""
import argparse
import json
import time
from pathlib import Path

try:
    from geopy.geocoders import Nominatim
    from geopy.exc import GeocoderTimedOut, GeocoderServiceError
except ImportError:
    raise SystemExit("Please install geopy (pip install geopy) before running this script")


DATA_PATH = Path(__file__).resolve().parent / 'data' / 'meru_projects.json'


def load_projects(path=DATA_PATH):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_projects(data, path):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def main(overwrite=False, delay=1.0):
    geolocator = Nominatim(user_agent="meru-projects-geocoder")
    data = load_projects()
    results = []
    failures = []

    for constituency, projects in data.items():
        for proj in projects:
            name = proj.get('name') or ''
            # Build a focused query: project name + constituency + Meru + Kenya
            query = f"{name}, {constituency}, Meru, Kenya"
            lat_key = next((k for k in proj.keys() if k.lower() in ('lat', 'latitude')), None)
            lon_key = next((k for k in proj.keys() if k.lower() in ('lon', 'longitude', 'long')), None)

            # If coordinates already present, skip (but you can overwrite by --overwrite)
            has_coords = lat_key and lon_key and proj.get(lat_key) is not None and proj.get(lon_key) is not None
            if has_coords and not overwrite:
                results.append((constituency, name, proj.get(lat_key), proj.get(lon_key), 'existing'))
                continue

            try:
                location = geolocator.geocode(query, exactly_one=True, timeout=10)
            except (GeocoderTimedOut, GeocoderServiceError) as e:
                failures.append((constituency, name, str(e)))
                time.sleep(delay)
                continue

            if location:
                lat, lon = location.latitude, location.longitude
                # write back using keys 'latitude' and 'longitude'
                proj['latitude'] = lat
                proj['longitude'] = lon
                results.append((constituency, name, lat, lon, 'geocoded'))
            else:
                failures.append((constituency, name, 'no-result'))

            time.sleep(delay)

    out_path = DATA_PATH.with_name('meru_projects.geocoded.json')
    if overwrite:
        out_path = DATA_PATH

    save_projects(data, out_path)

    # Write CSV reports
    import csv
    csv_path = out_path.with_suffix('.flagged.csv')
    with open(csv_path, 'w', newline='', encoding='utf-8') as cf:
        writer = csv.writer(cf)
        writer.writerow(['constituency', 'project', 'lat', 'lon', 'status'])
        for r in results:
            writer.writerow(r)
        for f in failures:
            writer.writerow([f[0], f[1], '', '', f[2]])

    print(f"Saved geocoded JSON to: {out_path}")
    print(f"Saved CSV report to: {csv_path}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Geocode Meru projects (Nominatim)')
    parser.add_argument('--overwrite', action='store_true', help='Overwrite source meru_projects.json')
    parser.add_argument('--delay', type=float, default=1.0, help='Seconds to sleep between requests (default 1.0)')
    args = parser.parse_args()
    main(overwrite=args.overwrite, delay=args.delay)
